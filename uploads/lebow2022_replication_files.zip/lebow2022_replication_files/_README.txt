
Description of replication files for Lebow (2022) "The Labor Market Effects of Venezuelan Migration to Colombia: Reconciling Conflicting Results"

"code" folder - all analysis files
"data" folder - data files aggregated at geographic unit (does not contain individual GEIH microdata, which must be requested from DANE)
"output" folder - contains tables and figures output by analysis files

------------------------------------------------------------------------------------------

The "code" folder contains the "_microdata_cleaning_files" that can only be run with access to the GEIH microdata containing the municipality identifier:

_1_microdata_clean.do - prepares labor outcome and all other variables in individual-level dataset

_2_microdata_collapse_metro_2010to2015 - takes mean within commuting-zone defined metro areas (metro) for key labor market outcomes between 2010-2015 (used to test for pre-trends, and to adjust for pre-trend in analysis)
Output: data/geih_metro_collapse_2010to2015.dta

_3_microdata_collapse_metro - Takes mean within metro areas for key labor market outcomes for 2014-2019 study period, restricted to natives. Also calculates migrant shares, the instrument, and internal migration rates. This is the primary file used in analysis.
Output: data/geih_metro_collapse.dta

_4_microdata_collapse_dpto_area - Repeats the above at the department level (dpto), or at the administrative metro area level (area)
Output: data/geih_dpto_area_collapse.dta

------------------------------------------------------------------------------------------

Two additional files in "data" used in the "_microdata_cleaning_files" are:
  - "mpio_metro_crosswalk.dta", mapping from mpios to metro areas generated in Duranton (2015)
  - "geih_occup_groups.dta", occupations ranked by mean schooling between 2010-2015

------------------------------------------------------------------------------------------

The "_master.do" runs files to generates each of the figures and tables using the .dta files in "data" and outputs them to "output"

Following is a notation guide for selected variables. Details for how they were generated can be found in the "_microdata_cleaning_files":

Primary outcomes:
ln_wage - log real wages, windsorized
ln_hrs - log hrs
lfp - labor force participation
unemp - unemployment
working - employment
formal - in the formal sector
sector groups: formw (formal market-wage), infmw (informal market-wage), ownacc (own-account), employer (employer)
occup_q_1-occup_q_5 - Ocupational skill group quintiles
occup_d_1-occup_d_10 - Ocupational skill group deciles
overskilled - self-reported over-skilled for job
pop - total population
pop_lfp - total workforce
pop_work - total working population
*_res - outcomes residualized from a regression on gender, age, education (see _1_microdata_clean.do)

Key analysis variables:
ven_5yr_sh - 5-year migrant share
iv_ven05 - shift-share instrument using 2005 census (see _3_microdata_collapse_metro.do)

Labor outcome subgroups:
*_m0 - male
*_m1 - female
*_e1 - not completed secondary
*_e2 - completed secondary
*_e3 - post-secondary
*_a1 - age 15-24
*_a2 - age 25-34
*_a3 - age 35-44
*_a4 - age 45-54
*_a5 - age 55-64
*_s1 - sector 1 (formal market-wage)
*_s2 - sector 2 (informal market-wage)
*_s3 - sector 3 (own-account)
*_s4 - sector 4 (employer)
*_oX - occupation skill quintile X
*_dX - occupation skill decile X





