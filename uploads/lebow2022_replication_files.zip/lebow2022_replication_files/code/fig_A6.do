

use "$mydir/data/geih_metro_collapse.dta", clear
replace ln_wage_res = ln_wage_res/100
reg ven_5yr_sh iv_ven05 i.metro i.year [aw=pop_work]
predict ven_5yr_sh_hat

reg ven_5yr_sh_hat i.metro i.year
predict ven_5yr_sh_hat_res, resid
reg ln_wage_res i.metro i.year
predict ln_wage_res_res, resid

# delimit;
twoway (scatter ln_wage_res_res ven_5yr_sh_hat_res, msym(oh) mcolor(gray)) (lfit ln_wage_res_res ven_5yr_sh_hat_res, lcolor(red) lpattern(dash))
		(lowess ln_wage_res_res ven_5yr_sh_hat_res, bw(.5) xlabel(-5(1)8) title("") lcolor(black) lpattern(solid)
		note("Bandwidth=.5, both variables residualized from metro and year fixed effects") legend(off)
		ytitle("Residual Ln(wage)") xtitle("Residual predicted migrant share"));
graph export "$mydir/output/figA6.png", replace;
