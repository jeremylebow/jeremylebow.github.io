


macro define iv1 "iv_ven05"
macro define iv2 "iv_ven93"
macro define iv3 "iv_dist"

* -------------------------------------------------
* ------------------ TABLE A3 ---------------------
* -------------------------------------------------

foreach r in 1 0 {

local m = 0
foreach x in "metro" "area" "dpto" {
	local m = `m' + 1
	
	if "`x'"=="metro" {
		use "$mydir/data/geih_metro_collapse.dta", clear
		}
	else if "`x'"=="area" | "`x'"=="dpto" {
		use "$mydir/data/geih_dpto_area_collapse.dta", clear
		rename `x'_ln_wage_res ln_wage_res
		rename `x'_pop_work pop_work
		rename ven_5yr_sh_`x' ven_5yr_sh
		rename iv_ven05_`x' iv_ven05
		rename iv_ven93_`x' iv_ven93
		rename iv_dist_`x'  iv_dist
		rename ven_5yr_sh_`x'_ret0 ven_5yr_sh_ret0
		rename iv_ven05_`x'_ret0 iv_ven05_ret0
		rename iv_ven93_`x'_ret0 iv_ven93_ret0
		rename iv_dist_`x'_ret0  iv_dist_ret0
		}
	if "`r'"=="0" {
		replace ven_5yr_sh = ven_5yr_sh_ret0
		replace iv_ven05 = iv_ven05_ret0
		replace iv_ven93 = iv_ven93_ret0
		replace iv_dist = iv_dist_ret0
		}
	* OLS TWFE
	qui reg ln_wage_res ven_5yr_sh i.`x' i.year [aw=pop_work], cluster(`x')
		global N`m'_i0_r`r': di %6.0gc e(N)
		global M`m'_i0_r`r': di %6.0gc e(N_clust)
		global b`m'_i0_r`r': di %6.2fc _b[ven_5yr_sh]
		global se`m'_i0_r`r': di %6.2fc _se[ven_5yr_sh]	
		qui test ven_5yr_sh = 0
		global p`m'_i0_r`r': di %6.3fc r(p)
		global st`m'_i0_r`r'=cond(${p`m'_i0_r`r'}<.01,"***",cond(${p`m'_i0_r`r'}<.05,"**",cond(${p`m'_i0_r`r'}<.1,"*","")))
	* IVs TWFE
	foreach i in 1 2 3 {
		qui ivreg2 ln_wage_res (ven_5yr_sh = ${iv`i'}) i.`x' i.year [aw=pop_work], cluster(`x') partial(i.`x' i.year)
			global N`m'_i`i'_r`r': di %6.0gc e(N)
			global M`m'_i`i'_r`r': di %6.0gc e(N_clust)
			global b`m'_i`i'_r`r': di %6.2fc _b[ven_5yr_sh]
			global se`m'_i`i'_r`r': di %6.2fc _se[ven_5yr_sh]	
			qui test ven_5yr_sh = 0
			global p`m'_i`i'_r`r': di %6.3fc r(p)
			global st`m'_i`i'_r`r'=cond(${p`m'_i`i'_r`r'}<.01,"***",cond(${p`m'_i`i'_r`r'}<.05,"**",cond(${p`m'_i`i'_r`r'}<.1,"*","")))
			global F`m'_i`i'_r`r': di %6.2fc e(widstat)
		}
	}
	}

* Stacked table
texdoc init "$mydir/output/tableA3.tex", replace force
tex \begin{threeparttable}
tex \setlength\extrarowheight{-5pt}
tex \begin{tabular}{l@{\hskip .4in}c@{\hskip .4in}ccc}
tex \toprule \toprule \addlinespace
tex & \multicolumn{4}{c}{\textbf\underline{{Panel A: Including Return Migrants}}} \\ \addlinespace
tex & (1) & (2) & (3) & (4) \\ \addlinespace
tex & OLS & IV: 2005 Census & IV: 1993 Census & IV: Inverse Distance \\ \addlinespace \midrule \addlinespace
tex & \multicolumn{4}{c}{\textbf\underline{{Geographic Unit: CZ Metro Areas}}} \\ \addlinespace
tex Migrant share  &${b1_i0_r1}${st1_i0_r1}&${b1_i1_r1}${st1_i1_r1}&${b1_i2_r1}${st1_i2_r1}&${b1_i3_r1}${st1_i3_r1}\\
tex 			   & (${se1_i0_r1})   	   & (${se1_i1_r1})   	   & (${se1_i2_r1})   	   & (${se1_i3_r1})  \\ \addlinespace
tex K-P Wald Stat. & 			  & ${F1_i1_r1} & ${F1_i2_r1} & ${F1_i3_r1} \\
tex Number of units	& ${M1_i0_r1} & ${M1_i1_r1} & ${M1_i2_r1} & ${M1_i3_r1} \\ \addlinespace \midrule \addlinespace
tex & \multicolumn{4}{c}{\textbf\underline{{Geographic Unit: Administrative Metro Areas}}} \\ \addlinespace
tex Migrant share  &${b2_i0_r1}${st2_i0_r1}&${b2_i1_r1}${st2_i1_r1}&${b2_i2_r1}${st2_i2_r1}&${b2_i3_r1}${st2_i3_r1}\\
tex 			   & (${se2_i0_r1})   	   & (${se2_i1_r1})   	   & (${se2_i2_r1})   	   & (${se2_i3_r1})  \\ \addlinespace
tex K-P Wald Stat. & 			  & ${F2_i1_r1} & ${F2_i2_r1} & ${F2_i3_r1} \\
tex Number of units	& ${M2_i0_r1} & ${M2_i1_r1} & ${M2_i2_r1} & ${M2_i3_r1} \\ \addlinespace\midrule \addlinespace
tex & \multicolumn{4}{c}{\textbf\underline{{Geographic Unit: Department}}} \\ \addlinespace 
tex Migrant share  &${b3_i0_r1}${st3_i0_r1}&${b3_i1_r1}${st3_i1_r1}&${b3_i2_r1}${st3_i2_r1}&${b3_i3_r1}${st3_i3_r1}\\
tex 			   & (${se3_i0_r1})   	   & (${se3_i1_r1})   	   & (${se3_i2_r1})   	   & (${se3_i3_r1}) \\ \addlinespace
tex K-P Wald Stat. & 			  & ${F3_i1_r1} & ${F3_i2_r1} & ${F3_i3_r1} \\
tex Number of units	& ${M3_i0_r1} & ${M3_i1_r1} & ${M3_i2_r1} & ${M3_i3_r1} \\ \addlinespace
tex \midrule\midrule \addlinespace
tex & \multicolumn{4}{c}{\textbf\underline{{Panel B: Excluding Return Migrants}}} \\ \addlinespace
tex & (5) & (6) & (7) & (8) \\ \addlinespace
tex & OLS & IV: 2005 Census & IV: 1993 Census & IV: Inverse Distance \\ \addlinespace \midrule \addlinespace
tex & \multicolumn{4}{c}{\textbf\underline{{Geographic Unit: CZ Metro Areas}}} \\ \addlinespace 
tex Migrant share  &${b1_i0_r0}${st1_i0_r0}&${b1_i1_r0}${st1_i1_r0}&${b1_i2_r0}${st1_i2_r0}&${b1_i3_r0}${st1_i3_r0}\\
tex 			   & (${se1_i0_r0})   	   & (${se1_i1_r0})   	   & (${se1_i2_r0})   	   & (${se1_i3_r0})  \\ \addlinespace
tex K-P Wald Stat. & 			  & ${F1_i1_r0} & ${F1_i2_r0} & ${F1_i3_r0} \\
tex Number of units	& ${M1_i0_r0} & ${M1_i1_r0} & ${M1_i2_r0} & ${M1_i3_r0} \\ \addlinespace \midrule \addlinespace
tex & \multicolumn{4}{c}{\textbf\underline{{Geographic Unit: Administrative Metro Areas}}} \\ \addlinespace
tex Migrant share  &${b2_i0_r0}${st2_i0_r0}&${b2_i1_r0}${st2_i1_r0}&${b2_i2_r0}${st2_i2_r0}&${b2_i3_r0}${st2_i3_r0}\\
tex 			   & (${se2_i0_r0})   	   & (${se2_i1_r0})   	   & (${se2_i2_r0})   	   & (${se2_i3_r0})  \\ \addlinespace
tex K-P Wald Stat. & 			  & ${F2_i1_r0} & ${F2_i2_r0} & ${F2_i3_r0} \\
tex Number of units	& ${M2_i0_r0} & ${M2_i1_r0} & ${M2_i2_r0} & ${M2_i3_r0} \\ \addlinespace \midrule \addlinespace
tex & \multicolumn{4}{c}{\textbf\underline{{Geographic Unit: Department}}} \\ \addlinespace
tex Migrant share  &${b3_i0_r0}${st3_i0_r0}&${b3_i1_r0}${st3_i1_r0}&${b3_i2_r0}${st3_i2_r0}&${b3_i3_r0}${st3_i3_r0}\\
tex 			   & (${se3_i0_r0})   	   & (${se3_i1_r0})   	   & (${se3_i2_r0})   	   & (${se3_i3_r0}) \\ \addlinespace
tex K-P Wald Stat. & 			  & ${F3_i1_r0} & ${F3_i2_r0} & ${F3_i3_r0} \\
tex Number of units	& ${M3_i0_r0} & ${M3_i1_r0} & ${M3_i2_r0} & ${M3_i3_r0} \\ \addlinespace
tex \bottomrule \bottomrule
tex \end{tabular}
tex \begin{tablenotes}
tex \small
tex \item The outcome, log hourly wage, is residualized and multiplied by 100. All models include Year FE and Unit FE. Panel A includes Colombian-born migrants in the migrant share, while Panel B excludes them.  Column 2-4 use different share components of the shift-share IV, based respectively on the complete 2005 census (as in the main analysis), the 10\% subsample of the 1993 census, and the inverse minimum driving distance from the metro area or department capital to the closest Venezuelan border crossing. Geographic units include the 79 commuting zone-defined metro areas (as in the main analysis), the 23 official metro areas of which the GEIH is representative, and the 24 departments of Colombia. Observations weighted by unit-year population. Cluster-robust standard errors in parentheses. * p$<$0.10, ** p$<$0.05, *** p$<$0.01.
tex \end{tablenotes}
tex \end{threeparttable}
texdoc close

* -------------------------------------------------
* ------------------ TABLE A4 ---------------------
* -------------------------------------------------

foreach g in a b c {
if "`g'"=="a" {
	local group = "geih19" //over 2019 pop
	local year = 2019
	}
else if "`g'"=="b" {
	local group = "geih18" //over 2018 pop
	local year = 2018
	}
else if "`g'"=="c" {
	local group = "censo18" //over 2018 pop
	local year = 2018
	}

foreach r in 1 0 {

local m = 0
foreach x in "metro" "area" "dpto" {
	local m = `m' + 1
	
	if "`x'"=="metro" {
		use "$mydir/data/geih_metro_collapse.dta", clear
		replace ven_5yr_sh = for_5yr_sh_`group'
		replace iv_ven05 = iv_ven05_`group'
		replace iv_ven93 = iv_ven93_`group'
		replace iv_dist = iv_dist_`group'
		replace ven_5yr_sh_ret0 = for_5yr_sh_`group'_ret0
		replace iv_ven05_ret0 = iv_ven05_`group'_ret0
		replace iv_ven93_ret0 = iv_ven93_`group'_ret0
		replace iv_dist_ret0 = iv_dist_`group'_ret0
		}
	else if "`x'"=="area" | "`x'"=="dpto" {
		use "$mydir/data/geih_dpto_area_collapse.dta", clear
		rename `x'_ln_wage_res ln_wage_res
		rename `x'_pop_work pop_work
		rename for_5yr_sh_`x'_`group'      ven_5yr_sh
		rename iv_ven05_`x'_`group'        iv_ven05
		rename iv_ven93_`x'_`group'        iv_ven93
		rename iv_dist_`x'_`group'         iv_dist
		rename for_5yr_sh_`x'_`group'_ret0 ven_5yr_sh_ret0
		rename iv_ven05_`x'_`group'_ret0   iv_ven05_ret0
		rename iv_ven93_`x'_`group'_ret0   iv_ven93_ret0
		rename iv_dist_`x'_`group'_ret0    iv_dist_ret0
		}
	if "`r'"=="0" {
		replace ven_5yr_sh = ven_5yr_sh_ret0
		replace iv_ven05 = iv_ven05_ret0
		replace iv_ven93 = iv_ven93_ret0
		replace iv_dist = iv_dist_ret0
		}

	* 2014-2018 difference model
	cap drop pop_work14
	foreach var of varlist ln_wage_res pop_work {
		gen temp = `var' if year==2014
		bysort `x': egen `var'2014 = max(temp)
		drop temp
		gen temp = `var' if year==`year'
		bysort `x': egen `var'`year' = max(temp)
		drop temp
		}
	gen ln_wage_res_dif = ln_wage_res`year' - ln_wage_res2014
	gen pop_work_mean = (pop_work`year' + pop_work2014)/2
	keep if year==2019

	* OLS DIF MODEL
	qui reg ln_wage_res_dif ven_5yr_sh [aw=pop_work_mean], robust
		global N`m'`g'_i0_r`r': di %6.0gc e(N)
		global b`m'`g'_i0_r`r': di %6.2fc _b[ven_5yr_sh]
		global se`m'`g'_i0_r`r': di %6.2fc _se[ven_5yr_sh]	
		qui test ven_5yr_sh = 0
		global p`m'`g'_i0_r`r': di %6.3fc r(p)
		global st`m'`g'_i0_r`r'=cond(${p`m'`g'_i0_r`r'}<.01,"***",cond(${p`m'`g'_i0_r`r'}<.05,"**",cond(${p`m'`g'_i0_r`r'}<.1,"*","")))
	* IVs DIF MODEL
	foreach i in 1 2 3 {
		 qui ivreg2 ln_wage_res_dif (ven_5yr_sh = ${iv`i'}) [aw=pop_work_mean], robust
			global N`m'`g'_i`i'_r`r': di %6.0gc e(N)
			global b`m'`g'_i`i'_r`r': di %6.2fc _b[ven_5yr_sh]
			global se`m'`g'_i`i'_r`r': di %6.2fc _se[ven_5yr_sh]	
			qui test ven_5yr_sh = 0
			global p`m'`g'_i`i'_r`r': di %6.3fc r(p)
			global st`m'`g'_i`i'_r`r'=cond(${p`m'`g'_i`i'_r`r'}<.01,"***",cond(${p`m'`g'_i`i'_r`r'}<.05,"**",cond(${p`m'`g'_i`i'_r`r'}<.1,"*","")))
			global F`m'`g'_i`i'_r`r': di %6.2fc e(widstat)
		}
	}
	}
	}

* Stacked table - NOTE - excluded "geih19" results from this table because of lack of space
texdoc init "$mydir/output/tableA4.tex", replace force
tex \begin{threeparttable}
tex \setlength\extrarowheight{-5pt}
tex \begin{tabular}{l@{\hskip .4in}c@{\hskip .4in}ccc}
tex \toprule \toprule \addlinespace
tex & \multicolumn{4}{c}{\textbf\underline{{Panel A: Including Return Migrants}}} \\ \addlinespace
tex & (1) & (2) & (3) & (4) \\ \addlinespace
tex & OLS & IV: 2005 Census & IV: 1993 Census & IV: Inverse Distance \\ \addlinespace \midrule \addlinespace
tex & \multicolumn{4}{c}{\textbf\underline{{Geographic Unit: CZ Metro Areas}}} \\ \addlinespace
tex Foreigner Share (2018 GEIH)	   &${b1b_i0_r1}${st1b_i0_r1}&${b1b_i1_r1}${st1b_i1_r1}&${b1b_i2_r1}${st1b_i2_r1}&${b1b_i3_r1}${st1b_i3_r1}\\
tex 			   				   & (${se1b_i0_r1})   	     & (${se1b_i1_r1})   	   & (${se1b_i2_r1})   	     & (${se1b_i3_r1})  \\ \addlinespace
tex Foreigner Share (2018 Census) &${b1c_i0_r1}${st1c_i0_r1}&${b1c_i1_r1}${st1c_i1_r1}&${b1c_i2_r1}${st1c_i2_r1}&${b1c_i3_r1}${st1c_i3_r1}\\
tex 			   				   & (${se1c_i0_r1})   	     & (${se1c_i1_r1})   	   & (${se1c_i2_r1})   	     & (${se1c_i3_r1})  \\ \addlinespace
tex Number of units	& ${N1c_i0_r1} & ${N1c_i1_r1} & ${N1c_i2_r1} & ${N1c_i3_r1} \\ \addlinespace \midrule \addlinespace
tex & \multicolumn{4}{c}{\textbf\underline{{Geographic Unit: Administrative Metro Areas}}} \\ \addlinespace
tex Foreigner Share (2018 GEIH)	   &${b2b_i0_r1}${st2b_i0_r1}&${b2b_i1_r1}${st2b_i1_r1}&${b2b_i2_r1}${st2b_i2_r1}&${b2b_i3_r1}${st2b_i3_r1}\\
tex 			                   & (${se2b_i0_r1})   	     & (${se2b_i1_r1})   	   & (${se2b_i2_r1})   	     & (${se2b_i3_r1})  \\ \addlinespace
tex Foreigner Share (2018 Census)	   &${b2c_i0_r1}${st2c_i0_r1}&${b2c_i1_r1}${st2c_i1_r1}&${b2c_i2_r1}${st2c_i2_r1}&${b2c_i3_r1}${st2c_i3_r1}\\
tex 			                   & (${se2c_i0_r1})   	     & (${se2c_i1_r1})   	   & (${se2c_i2_r1})   	     & (${se2c_i3_r1})  \\ \addlinespace
tex Number of units	& ${N2c_i0_r1} & ${N2c_i1_r1} & ${N2c_i2_r1} & ${N2c_i3_r1} \\ \addlinespace\midrule \addlinespace
tex & \multicolumn{4}{c}{\textbf\underline{{Geographic Unit: Department}}} \\ \addlinespace 
tex Foreigner Share (2018 GEIH)	   &${b3b_i0_r1}${st3b_i0_r1}&${b3b_i1_r1}${st3b_i1_r1}&${b3b_i2_r1}${st3b_i2_r1}&${b3b_i3_r1}${st3b_i3_r1}\\
tex 			 				   & (${se3b_i0_r1})   	     & (${se3b_i1_r1})   	   & (${se3b_i2_r1})   	     & (${se3b_i3_r1}) \\ \addlinespace
tex Foreigner Share (2018 Census)	   &${b3c_i0_r1}${st3c_i0_r1}&${b3c_i1_r1}${st3c_i1_r1}&${b3c_i2_r1}${st3c_i2_r1}&${b3c_i3_r1}${st3c_i3_r1}\\
tex 			 				   & (${se3c_i0_r1})   	     & (${se3c_i1_r1})   	   & (${se3c_i2_r1})   	     & (${se3c_i3_r1}) \\ \addlinespace
tex Number of units	& ${N3c_i0_r1} & ${N3c_i1_r1} & ${N3c_i2_r1} & ${N3c_i3_r1} \\ \addlinespace
tex \midrule\midrule \addlinespace

tex & \multicolumn{4}{c}{\textbf\underline{{Panel B: Excluding Return Migrants}}} \\ \addlinespace
tex & (5) & (6) & (7) & (8) \\ \addlinespace
tex & OLS & IV: 2005 Census & IV: 1993 Census & IV: Inverse Distance \\ \addlinespace \midrule \addlinespace
tex & \multicolumn{4}{c}{\textbf\underline{{Geographic Unit: CZ Metro Areas}}} \\ \addlinespace
tex Foreigner Share (2018 GEIH)	   &${b1b_i0_r0}${st1b_i0_r0}&${b1b_i1_r0}${st1b_i1_r0}&${b1b_i2_r0}${st1b_i2_r0}&${b1b_i3_r0}${st1b_i3_r0}\\
tex 			   				   & (${se1b_i0_r0})   	     & (${se1b_i1_r0})   	   & (${se1b_i2_r0})   	     & (${se1b_i3_r0})  \\ \addlinespace
tex Foreigner Share (2018 Census)	   &${b1c_i0_r0}${st1c_i0_r0}&${b1c_i1_r0}${st1c_i1_r0}&${b1c_i2_r0}${st1c_i2_r0}&${b1c_i3_r0}${st1c_i3_r0}\\
tex 			   				   & (${se1c_i0_r0})   	     & (${se1c_i1_r0})   	   & (${se1c_i2_r0})   	     & (${se1c_i3_r0})  \\ \addlinespace
tex Number of units	& ${N1c_i0_r0} & ${N1c_i1_r0} & ${N1c_i2_r0} & ${N1c_i3_r0} \\ \addlinespace \midrule \addlinespace
tex & \multicolumn{4}{c}{\textbf\underline{{Geographic Unit: Administrative Metro Areas}}} \\ \addlinespace
tex Foreigner Share (2018 GEIH)	   &${b2b_i0_r0}${st2b_i0_r0}&${b2b_i1_r0}${st2b_i1_r0}&${b2b_i2_r0}${st2b_i2_r0}&${b2b_i3_r0}${st2b_i3_r0}\\
tex 			                   & (${se2b_i0_r0})   	     & (${se2b_i1_r0})   	   & (${se2b_i2_r0})   	     & (${se2b_i3_r0})  \\ \addlinespace
tex Foreigner Share (2018 Census)	   &${b2c_i0_r0}${st2c_i0_r0}&${b2c_i1_r0}${st2c_i1_r0}&${b2c_i2_r0}${st2c_i2_r0}&${b2c_i3_r0}${st2c_i3_r0}\\
tex 			                   & (${se2c_i0_r0})   	     & (${se2c_i1_r0})   	   & (${se2c_i2_r0})   	     & (${se2c_i3_r0})  \\ \addlinespace
tex Number of units	& ${N2c_i0_r0} & ${N2c_i1_r0} & ${N2c_i2_r0} & ${N2c_i3_r0} \\ \addlinespace\midrule \addlinespace
tex & \multicolumn{4}{c}{\textbf\underline{{Geographic Unit: Department}}} \\ \addlinespace 
tex Foreigner Share (2018 GEIH)	   &${b3b_i0_r0}${st3b_i0_r0}&${b3b_i1_r0}${st3b_i1_r0}&${b3b_i2_r0}${st3b_i2_r0}&${b3b_i3_r0}${st3b_i3_r0}\\
tex 			 				   & (${se3b_i0_r0})   	     & (${se3b_i1_r0})   	   & (${se3b_i2_r0})   	     & (${se3b_i3_r0}) \\ \addlinespace
tex Foreigner Share (2018 Census)	   &${b3c_i0_r0}${st3c_i0_r0}&${b3c_i1_r0}${st3c_i1_r0}&${b3c_i2_r0}${st3c_i2_r0}&${b3c_i3_r0}${st3c_i3_r0}\\
tex 			 				   & (${se3c_i0_r0})   	     & (${se3c_i1_r0})   	   & (${se3c_i2_r0})   	     & (${se3c_i3_r0}) \\ \addlinespace
tex Number of units	& ${N3c_i0_r0} & ${N3c_i1_r0} & ${N3c_i2_r0} & ${N3c_i3_r0} \\ \addlinespace
tex \bottomrule \bottomrule
tex \end{tabular}
tex \begin{tablenotes}
tex \small
tex \item See notes to previous table. This model is a regression of the change in residual wages from 2014 to 2018 on the 2018 foreigner share, calculated using the GEIH or Census as a share of the 2018 population. The instrument is created analogously (interacted with the national migration rate from the GEIH or census). In no case does the K-P Wald stat fall below 10.
tex \end{tablenotes}
tex \end{threeparttable}
texdoc close

* -------------------------------------------------
* ------------------ TABLE A5 ---------------------
* -------------------------------------------------

macro define iv1 "iv_ven05"
macro define iv2 "iv_ven93"
macro define iv3 "iv_dist"

foreach r in 1 0 {

local m = 0
foreach x in "metro" "area" "dpto" {
	local m = `m' + 1
	
	if "`x'"=="metro" {
		use "$mydir/data/geih_metro_collapse.dta", clear
		replace iv_ven05 = iv_ven05_1yr
		replace iv_ven93 = iv_ven93_1yr
		replace iv_dist = iv_dist_1yr
		}
	else if "`x'"=="area" | "`x'"=="dpto" {
		use "$mydir/data/geih_dpto_area_collapse.dta", clear
		rename `x'_ln_wage_res ln_wage_res
		rename `x'_pop_work pop_work
		rename ven_1yr_sh_`x' ven_1yr_sh
		rename iv_ven05_`x'_1yr iv_ven05
		rename iv_ven93_`x'_1yr iv_ven93
		rename iv_dist_`x'_1yr  iv_dist
		rename ven_1yr_sh_`x'_ret0 ven_1yr_sh_ret0
		rename iv_ven05_`x'_ret0_1yr iv_ven05_ret0
		rename iv_ven93_`x'_ret0_1yr iv_ven93_ret0
		rename iv_dist_`x'_ret0_1yr  iv_dist_ret0
		}
	if "`r'"=="0" {
		replace ven_1yr_sh = ven_1yr_sh_ret0
		replace iv_ven05 = iv_ven05_ret0
		replace iv_ven93 = iv_ven93_ret0
		replace iv_dist = iv_dist_ret0
		}
	foreach y in 7 8 9 {
	
		* OLS TWFE
		qui reg ln_wage_res ven_1yr_sh i.`x' i.year if year<=2010+`y' [aw=pop_work], cluster(`x')
			global N`m'`y'_i0_r`r': di %6.0gc e(N)
			global M`m'`y'_i0_r`r': di %6.0gc e(N_clust)
			global b`m'`y'_i0_r`r': di %6.2fc _b[ven_1yr_sh]
			global se`m'`y'_i0_r`r': di %6.2fc _se[ven_1yr_sh]	
			qui test ven_1yr_sh = 0
			global p`m'`y'_i0_r`r': di %6.3fc r(p)
			global st`m'`y'_i0_r`r'=cond(${p`m'`y'_i0_r`r'}<.01,"***",cond(${p`m'`y'_i0_r`r'}<.05,"**",cond(${p`m'`y'_i0_r`r'}<.1,"*","")))
		* IVs TWFE
		foreach i in 1 2 3 {
			qui ivreg2 ln_wage_res (ven_1yr_sh = ${iv`i'}) i.`x' i.year if year<=2010+`y' [aw=pop_work], cluster(`x') partial(i.`x' i.year)
				global N`m'`y'_i`i'_r`r': di %6.0gc e(N)
				global M`m'`y'_i`i'_r`r': di %6.0gc e(N_clust)
				global b`m'`y'_i`i'_r`r': di %6.2fc _b[ven_1yr_sh]
				global se`m'`y'_i`i'_r`r': di %6.2fc _se[ven_1yr_sh]	
				qui test ven_1yr_sh = 0
				global p`m'`y'_i`i'_r`r': di %6.3fc r(p)
				global st`m'`y'_i`i'_r`r'=cond(${p`m'`y'_i`i'_r`r'}<.01,"***",cond(${p`m'`y'_i`i'_r`r'}<.05,"**",cond(${p`m'`y'_i`i'_r`r'}<.1,"*","")))
				global F`m'`y'_i`i'_r`r': di %6.2fc e(widstat)
			}
		}
	}
	}

* Stacked table
texdoc init "$mydir/output/tableA5.tex", replace force
tex \begin{threeparttable}
tex \setlength\extrarowheight{-5pt}
tex \begin{tabular}{l@{\hskip .4in}c@{\hskip .4in}ccc}
tex \toprule \toprule \addlinespace
tex & \multicolumn{4}{c}{\textbf\underline{{Panel A: Including Return Migrants}}} \\ \addlinespace
tex & (1) & (2) & (3) & (4) \\ \addlinespace
tex & OLS & IV: 2005 Census & IV: 1993 Census & IV: Inverse Distance \\ \addlinespace \midrule \addlinespace
tex & \multicolumn{4}{c}{\textbf\underline{{Geographic Unit: CZ Metro Areas}}} \\ \addlinespace
tex 1-Year Migrant Share (Data until 2019)	&${b19_i0_r1}${st19_i0_r1}&${b19_i1_r1}${st19_i1_r1}&${b19_i2_r1}${st19_i2_r1}&${b19_i3_r1}${st19_i3_r1}\\
tex 			   				   			& (${se19_i0_r1})   	     & (${se19_i1_r1})   	   & (${se19_i2_r1})   	     & (${se19_i3_r1})  \\ \addlinespace
tex 1-Year Migrant Share (Data until 2017) &${b17_i0_r1}${st17_i0_r1}&${b17_i1_r1}${st17_i1_r1}&${b17_i2_r1}${st17_i2_r1}&${b17_i3_r1}${st17_i3_r1}\\
tex 			   		  		   			& (${se17_i0_r1})   	    & (${se17_i1_r1})   	  & (${se17_i2_r1})   	    & (${se17_i3_r1})  \\ \addlinespace
tex Number of units	   & ${M17_i0_r1}  & ${M17_i1_r1} & ${M17_i2_r1} & ${M17_i3_r1} \\ \addlinespace 
tex \midrule \addlinespace
tex & \multicolumn{4}{c}{\textbf\underline{{Geographic Unit: Administrative Metro Areas}}} \\ \addlinespace
tex 1-Year Migrant Share (Data until 2019)	&${b29_i0_r1}${st29_i0_r1}&${b29_i1_r1}${st29_i1_r1}&${b29_i2_r1}${st29_i2_r1}&${b29_i3_r1}${st29_i3_r1}\\
tex 			   				   			& (${se29_i0_r1})   	     & (${se29_i1_r1})   	   & (${se29_i2_r1})   	     & (${se29_i3_r1})  \\ \addlinespace
tex 1-Year Migrant Share (Data until 2017) &${b27_i0_r1}${st27_i0_r1}&${b27_i1_r1}${st27_i1_r1}&${b27_i2_r1}${st27_i2_r1}&${b27_i3_r1}${st27_i3_r1}\\
tex 			   		  		   			& (${se27_i0_r1})   	    & (${se27_i1_r1})   	  & (${se27_i2_r1})   	    & (${se27_i3_r1})  \\ \addlinespace
tex Number of units	   & ${M27_i0_r1}  & ${M27_i1_r1} & ${M27_i2_r1} & ${M27_i3_r1} \\ \addlinespace 
tex \midrule \addlinespace
tex & \multicolumn{4}{c}{\textbf\underline{{Geographic Unit: Department}}} \\ \addlinespace 
tex 1-Year Migrant Share (Data until 2019)	&${b39_i0_r1}${st39_i0_r1}&${b39_i1_r1}${st39_i1_r1}&${b39_i2_r1}${st39_i2_r1}&${b39_i3_r1}${st39_i3_r1}\\
tex 			   				   			& (${se39_i0_r1})   	     & (${se39_i1_r1})   	   & (${se39_i2_r1})   	     & (${se39_i3_r1})  \\ \addlinespace
tex 1-Year Migrant Share (Data until 2017) &${b37_i0_r1}${st37_i0_r1}&${b37_i1_r1}${st37_i1_r1}&${b37_i2_r1}${st37_i2_r1}&${b37_i3_r1}${st37_i3_r1}\\
tex 			   		  		   			& (${se37_i0_r1})   	    & (${se37_i1_r1})   	  & (${se37_i2_r1})   	    & (${se37_i3_r1})  \\ \addlinespace
tex Number of units	   & ${M37_i0_r1}  & ${M37_i1_r1} & ${M37_i2_r1} & ${M37_i3_r1} \\ \addlinespace 
tex \midrule\midrule \addlinespace

tex & \multicolumn{4}{c}{\textbf\underline{{Panel B: Excluding Return Migrants}}} \\ \addlinespace
tex & (5) & (6) & (7) & (8) \\ \addlinespace
tex & OLS & IV: 2005 Census & IV: 1993 Census & IV: Inverse Distance \\ \addlinespace \midrule \addlinespace
tex & \multicolumn{4}{c}{\textbf\underline{{Geographic Unit: CZ Metro Areas}}} \\ \addlinespace
tex 1-Year Migrant Share (Data until 2019)	&${b19_i0_r0}${st19_i0_r0}&${b19_i1_r0}${st19_i1_r0}&${b19_i2_r0}${st19_i2_r0}&${b19_i3_r0}${st19_i3_r0}\\
tex 			   				   			& (${se19_i0_r0})   	     & (${se19_i1_r0})   	   & (${se19_i2_r0})   	     & (${se19_i3_r0})  \\ \addlinespace
tex 1-Year Migrant Share (Data until 2017) &${b17_i0_r0}${st17_i0_r0}&${b17_i1_r0}${st17_i1_r0}&${b17_i2_r0}${st17_i2_r0}&${b17_i3_r0}${st17_i3_r0}\\
tex 			   		  		   			& (${se17_i0_r0})   	    & (${se17_i1_r0})   	  & (${se17_i2_r0})   	    & (${se17_i3_r0})  \\ \addlinespace
tex Number of units	   & ${M17_i0_r0}  & ${M17_i1_r0} & ${M17_i2_r0} & ${M17_i3_r0} \\ \addlinespace 
tex \midrule \addlinespace
tex & \multicolumn{4}{c}{\textbf\underline{{Geographic Unit: Administrative Metro Areas}}} \\ \addlinespace
tex 1-Year Migrant Share (Data until 2019)	&${b29_i0_r0}${st29_i0_r0}&${b29_i1_r0}${st29_i1_r0}&${b29_i2_r0}${st29_i2_r0}&${b29_i3_r0}${st29_i3_r0}\\
tex 			   				   			& (${se29_i0_r0})   	     & (${se29_i1_r0})   	   & (${se29_i2_r0})   	     & (${se29_i3_r0})  \\ \addlinespace
tex 1-Year Migrant Share (Data until 2017) &${b27_i0_r0}${st27_i0_r0}&${b27_i1_r0}${st27_i1_r0}&${b27_i2_r0}${st27_i2_r0}&${b27_i3_r0}${st27_i3_r0}\\
tex 			   		  		   			& (${se27_i0_r0})   	    & (${se27_i1_r0})   	  & (${se27_i2_r0})   	    & (${se27_i3_r0})  \\ \addlinespace
tex Number of units	   & ${M27_i0_r0}  & ${M27_i1_r0} & ${M27_i2_r0} & ${M27_i3_r0} \\ \addlinespace 
tex \midrule \addlinespace
tex & \multicolumn{4}{c}{\textbf\underline{{Geographic Unit: Department}}} \\ \addlinespace 
tex 1-Year Migrant Share (Data until 2019)	&${b39_i0_r0}${st39_i0_r0}&${b39_i1_r0}${st39_i1_r0}&${b39_i2_r0}${st39_i2_r0}&${b39_i3_r0}${st39_i3_r0}\\
tex 			   				   			& (${se39_i0_r0})   	     & (${se39_i1_r0})   	   & (${se39_i2_r0})   	     & (${se39_i3_r0})  \\ \addlinespace
tex 1-Year Migrant Share (Data until 2017) &${b37_i0_r0}${st37_i0_r0}&${b37_i1_r0}${st37_i1_r0}&${b37_i2_r0}${st37_i2_r0}&${b37_i3_r0}${st37_i3_r0}\\
tex 			   		  		   			& (${se37_i0_r0})   	    & (${se37_i1_r0})   	  & (${se37_i2_r0})   	    & (${se37_i3_r0})  \\ \addlinespace
tex Number of units	   & ${M37_i0_r0}  & ${M37_i1_r0} & ${M37_i2_r0} & ${M37_i3_r0} \\ \addlinespace 
tex \bottomrule \bottomrule
tex \end{tabular}
tex \begin{tablenotes}
tex \small
tex \item See notes to previous table. This is the original two-way fixed effects model, replacing the 5-year migrant share with the 1-year migrant share (the share of the population that arrived from Venezuela in the past 12 months), and varying the end of the period of analysis. In no case does the K-P Wald stat fall below 10.
tex \end{tablenotes}
tex \end{threeparttable}
texdoc close
