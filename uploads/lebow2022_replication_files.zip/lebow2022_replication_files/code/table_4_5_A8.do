


macro define lbl    "All"
macro define lbl_m0 "Female"
macro define lbl_m1 "Male"
macro define lbl_e1 "Less than Secondary"
macro define lbl_e2 "Secondary"
macro define lbl_e3 "Post-Secondary"
macro define lbl_a1 "Age 15-24"
macro define lbl_a2 "Age 25-34"
macro define lbl_a3 "Age 35-44"
macro define lbl_a4 "Age 45-54"
macro define lbl_a5 "Age 55-64"

* ------------------------------------------------------
* ------------------ TABLE 4 and 5 ---------------------
* ------------------------------------------------------

use "$mydir/data/geih_metro_collapse.dta", clear

foreach g in "" "_m0" "_m1" "_a1" "_a2" "_a3" "_a4" "_a5" "_e1" "_e2" "_e3" {
	
	*Occupation Groups
	foreach v of numlist 1/5 {
		qui ivreg2 occup_q_`v'`g' (ven_5yr_sh = iv_ven05) i.metro i.year [aw=pop`g'], cluster(metro) partial(i.metro i.year)
		global N_`v'`g': di %6.0gc e(N)
		global b_`v'`g': di %6.2fc _b[ven_5yr_sh]
		global se_`v'`g': di %6.2fc _se[ven_5yr_sh]
		qui test ven_5yr_sh = 0
		global p_`v'`g': di %6.3fc r(p)
		global st_`v'`g'=cond(${p_`v'`g'}<.01,"***",cond(${p_`v'`g'}<.05,"**",cond(${p_`v'`g'}<.1,"*","")))
		global F_`v'`g': di %6.2fc e(widstat)
		}
		
	* Under-employment
	qui ivreg2 overskilled`g' (ven_5yr_sh = iv_ven05) i.metro i.year [aw=pop`g'], cluster(metro) partial(i.metro i.year)
		global N_6`g': di %6.0gc e(N)
		global b_6`g': di %6.2fc _b[ven_5yr_sh]
		global se_6`g': di %6.2fc _se[ven_5yr_sh]
		qui test ven_5yr_sh = 0
		global p_6`g': di %6.3fc r(p)
		global st_6`g'=cond(${p_6`g'}<.01,"***",cond(${p_6`g'}<.05,"**",cond(${p_6`g'}<.1,"*","")))
		global F_6`g': di %6.2fc e(widstat)

	*Sector Groups
	local v = 6
	foreach var of varlist formw infmw ownacc employer {
		local v = `v' + 1
		qui ivreg2 `var'`g' (ven_5yr_sh = iv_ven05) i.metro i.year [aw=pop`g'], cluster(metro) partial(i.metro i.year)
		global N_`v'`g': di %6.0gc e(N)
		global b_`v'`g': di %6.2fc _b[ven_5yr_sh]
		global se_`v'`g': di %6.2fc _se[ven_5yr_sh]
		qui test ven_5yr_sh = 0
		global p_`v'`g': di %6.3fc r(p)
		global st_`v'`g'=cond(${p_`v'`g'}<.01,"***",cond(${p_`v'`g'}<.05,"**",cond(${p_`v'`g'}<.1,"*","")))
		global F_`v'`g': di %6.2fc e(widstat)
		}
	}

texdoc init "$mydir/output/table4.tex", replace force
tex \begin{threeparttable}
tex \setlength\extrarowheight{-5pt}
tex \begin{tabular}{lc@{\hskip .3in}c@{\hskip .3in}c@{\hskip .3in}c@{\hskip .3in}c@{\hskip .3in}cc}
tex \toprule \toprule
tex & (1) & (2) & (3) & (4) & (5) & (6) & (7) \\
tex & Occup & Occup & Occup & Occup & Occup & Under-   & \\
tex & Grp 1 & Grp 2 & Grp 3 & Grp 4 & Grp 5 & Employed & K-P Stat.\\ \addlinespace \midrule \addlinespace
foreach g in "" "_m0" "_m1" "_a1" "_a2" "_a3" "_a4" "_a5" "_e1" "_e2" "_e3" {
	tex ${lbl`g'}
	foreach v of numlist 1/6 {
		tex & ${b_`v'`g'}${st_`v'`g'}
		}
	tex & ${F_1`g'} \\
	foreach v of numlist 1/6 {
		tex & (${se_`v'`g'})
		}
	tex \\ \addlinespace
	if "`g'"=="" | "`g'"=="_m1" | "`g'"=="_a5" {
		tex \addlinespace \midrule \addlinespace
		}
	}
tex \bottomrule \bottomrule
tex \end{tabular}
tex \begin{tablenotes}
tex \small
tex \item All models are 2SLS linear probability models for probability of employment in a group (multiplied by 100), not conditional on working, with Year FE and City FE. Occupations ranked according to mean education of natives pre-2015 and grouped into quintiles. Workers are under-employed if they say they would like to change jobs to improve use of skills or trianing. Observations weighted by city-year-group population. Cluster-robust standard errors in parentheses. * p$<$0.10, ** p$<$0.05, *** p$<$0.01.
tex \end{tablenotes}
tex \end{threeparttable}
texdoc close

texdoc init "$mydir/output/table5.tex", replace force
tex \begin{threeparttable}
tex \setlength\extrarowheight{-5pt}
tex \begin{tabular}{l@{\hskip .2in}c@{\hskip .4in}cccc}
tex \toprule \toprule
tex & (1) & (2) & (3) & (4) & (5) \\
tex & Formal   & Informal & Own-Account & Employer & \\
tex & Salaried & Salaried & 			& 		   & K-P Stat.\\ \addlinespace \midrule \addlinespace
foreach g in "" "_m0" "_m1" "_a1" "_a2" "_a3" "_a4" "_a5" "_e1" "_e2" "_e3" {
	tex ${lbl`g'}
	foreach v of numlist 7/10 {
		tex & ${b_`v'`g'}${st_`v'`g'}
		}
	tex & ${F_1`g'} \\
	foreach v of numlist 7/10 {
		tex & (${se_`v'`g'})
		}
	tex \\ \addlinespace
	if "`g'"=="" | "`g'"=="_m1" | "`g'"=="_a5" {
		tex \addlinespace \midrule \addlinespace
		}
	}
tex \bottomrule \bottomrule
tex \end{tabular}
tex \begin{tablenotes}
tex \small
tex \item Models are 2SLS linear probability models for probability of employment in a group (multiplied by 100), not conditional on working, with Year FE and City FE. Wage-sector workers are split by formality, defined according to compliance with mandatory health and pension schemes. Self employed workers are split into own-account (with no employees, predominantly informal) and employer. Observations weighted by city-year-group population. Cluster-robust standard errors in parentheses. * p$<$0.10, ** p$<$0.05, *** p$<$0.01.
tex \end{tablenotes}
tex \end{threeparttable}
texdoc close

* --------------------------------------------------------------
* ------------------ TABLE A8 - Robustness ---------------------
* --------------------------------------------------------------

macro define lbl_m01 "Original"
macro define lbl_m02 "2SLS"
macro define lbl_m03 ""
macro define lbl_m11 "Drop $<$100km"
macro define lbl_m12 "from Border"
macro define lbl_m13 ""
macro define lbl_m21 "Control"
macro define lbl_m22 "Trade with"
macro define lbl_m23 "Venezuela"
macro define lbl_m31 "Year Trend X"
macro define lbl_m32 "Inv Distance"
macro define lbl_m33 "to Border"
macro define lbl_m41 "Year Trend X"
macro define lbl_m42 "Region"
macro define lbl_m43 ""
macro define lbl_m51 "Year Trend X"
macro define lbl_m52 "Pre-trend"
macro define lbl_m53 ""
macro define lbl_m61 "Drop"
macro define lbl_m62 "Bogotá"
macro define lbl_m63 ""
macro define lbl_m71 "Drop Metro"
macro define lbl_m72 "Yrly Sample"
macro define lbl_m73 "$<$1,000"
macro define lbl_m81 "2014-2019"
macro define lbl_m82 "Difference"
macro define lbl_m83 "Model"
macro define lbl_m91 "Kronmal"
macro define lbl_m92 "Specification"
macro define lbl_m93 ""
macro define lbl_m101 "Assign"
macro define lbl_m102 "Natives to"
macro define lbl_m103 "Past Metro"

macro define outcome_list "occup_q_1 occup_q_2 occup_q_3 occup_q_4 occup_q_5 overskilled formw infmw ownacc employer"

foreach m in "m0" "m1" "m2" "m3" "m4" "m5" "m6" "m7" "m8" "m9" "m10" {

	use "$mydir/data/geih_metro_collapse.dta", clear

	if "`m'"=="m10" {
		foreach var of varlist $outcome_list pop {
			replace `var'  = `var'_pastmetro
			}
		}
	
	if "`m'"=="m9" {	
		replace ven_5yr_sh = ven_5yr/100
		}

	if "`m'"=="m8" {
		local add = "14"
		local dif = "_dif"
		local partial = ""
		foreach var of varlist ven_5yr_sh iv_ven05 $outcome_list {
			cap drop `var'14
			gen temp = `var' if year==2014
			bysort metro: egen `var'14 = max(temp)
			drop temp
			gen temp = `var' if year==2019
			bysort metro: egen `var'19 = max(temp)
			drop temp
			gen `var'_dif = `var'19 - `var'14
			}
		}
	else if "`m'"!="m8" {
		local add = ""
		local dif = ""
		local partial = "partial(i.metro i.year)"
		}

	local v=0
	foreach var of varlist $outcome_list {
		local v = `v'+1

		macro define m0 "(ven_5yr_sh = iv_ven05) i.metro i.year" //Original
		macro define m1 "(ven_5yr_sh = iv_ven05) i.metro i.year if dist_km_border_crossings>100" //No within 100km of border
		macro define m2 "(ven_5yr_sh = iv_ven05) i.metro i.year imp_ven exp_ven" //Control trade
		macro define m3 "(ven_5yr_sh = iv_ven05) i.metro i.year yearXinvdist" //Border distance X Year trend
		macro define m4 "(ven_5yr_sh = iv_ven05) i.metro i.year r_*Xyear" //Region X Year trend
		macro define m5 "(ven_5yr_sh = iv_ven05) i.metro i.year yearX`var'_13_15" //Pre-trend trend X Year trend
		macro define m6 "(ven_5yr_sh = iv_ven05) i.metro i.year if metro!=11001" //No Bogota
		macro define m7 "(ven_5yr_sh = iv_ven05) i.metro i.year if pop14>1000" //Increase SS restriction to min 1,000-year
		macro define m8 "(ven_5yr_sh_dif = iv_ven05_dif) if year==2019" //2014-2019 difference model
		macro define m9 "(ven_5yr_sh = iv_ven05) year*Xpop14 i.metro i.year" //Kronmal specification (ven_5yr in numbers, control pop)
		macro define m10 "(ven_5yr_sh = iv_ven05) i.metro i.year" //Past metro (same as original)

		qui ivreg2 `var'`dif' ${`m'} [aw=pop`add'], cluster(metro) `partial'
			global N_v`v'_`m': di %6.0gc e(N)
			global M_v`v'_`m': di %6.0gc e(N_clust)
			global b_v`v'_`m': di %6.2fc _b[ven_5yr]
			global se_v`v'_`m': di %6.2fc _se[ven_5yr]	
			qui test ven_5yr = 0
			global p_v`v'_`m': di %6.3fc r(p)
			global st_v`v'_`m'=cond(${p_v`v'_`m'}<.01,"***",cond(${p_v`v'_`m'}<.05,"**",cond(${p_v`v'_`m'}<.1,"*","")))
			global F_v`v'_`m': di %6.2fc e(widstat)
			}
		}

texdoc init "$mydir/output/tableA8.tex", replace force
tex \begin{threeparttable}
tex \setlength\extrarowheight{-5pt}
tex \begin{tabular}{lc@{\hskip .3in}c@{\hskip .3in}c@{\hskip .3in}c@{\hskip .3in}c@{\hskip .3in}c@{\hskip .3in}c@{\hskip .3in}c@{\hskip .3in}c@{\hskip .3in}c@{\hskip .3in}c}
tex \toprule \toprule
tex & (1) & (2) & (3) & (4) & (5) & (6) & (7) & (8) & (9) & (10) & (11) \\ \addlinespace
tex & $lbl_m01 & $lbl_m11 & $lbl_m21 & $lbl_m31 & $lbl_m41 & $lbl_m51 & $lbl_m61 & $lbl_m71 & $lbl_m81 & $lbl_m91 & $lbl_m101 \\
tex & $lbl_m02 & $lbl_m12 & $lbl_m22 & $lbl_m32 & $lbl_m42 & $lbl_m52 & $lbl_m62 & $lbl_m72 & $lbl_m82 & $lbl_m92 & $lbl_m102 \\
tex & $lbl_m03 & $lbl_m13 & $lbl_m23 & $lbl_m33 & $lbl_m43 & $lbl_m53 & $lbl_m63 & $lbl_m73 & $lbl_m83 & $lbl_m93 & $lbl_m103 \\ \addlinespace \midrule
tex Occup Skill Group 1 &${b_v1_m0}${st_v1_m0}&${b_v1_m1}${st_v1_m1}&${b_v1_m2}${st_v1_m2}&${b_v1_m3}${st_v1_m3}&${b_v1_m4}${st_v1_m4}&${b_v1_m5}${st_v1_m5}&${b_v1_m6}${st_v1_m6}&${b_v1_m7}${st_v1_m7}&${b_v1_m8}${st_v1_m8}&${b_v1_m9}${st_v1_m9}&${b_v1_m10}${st_v1_m10}\\
tex 		      & (${se_v1_m0})	      & (${se_v1_m1})	   	& (${se_v1_m2})	      & (${se_v1_m3})	    & (${se_v1_m4})	      & (${se_v1_m5})	   	& (${se_v1_m6})	   	  & (${se_v1_m7})  & (${se_v1_m8})  & (${se_v1_m9}) & (${se_v1_m10})	   	\\ \addlinespace
tex Occup Skill Group 2 &${b_v2_m0}${st_v2_m0}&${b_v2_m1}${st_v2_m1}&${b_v2_m2}${st_v2_m2}&${b_v2_m3}${st_v2_m3}&${b_v2_m4}${st_v2_m4}&${b_v2_m5}${st_v2_m5}&${b_v2_m6}${st_v2_m6}&${b_v2_m7}${st_v2_m7}&${b_v2_m8}${st_v2_m8}&${b_v2_m9}${st_v2_m9}&${b_v2_m10}${st_v2_m10}\\
tex 		      & (${se_v2_m0})	      & (${se_v2_m1})	   	& (${se_v2_m2})	      & (${se_v2_m3})	    & (${se_v2_m4})	      & (${se_v2_m5})	   	& (${se_v2_m6})	   	  & (${se_v2_m7})  & (${se_v2_m8})  & (${se_v2_m9}) & (${se_v2_m10})	   	\\ \addlinespace
tex Occup Skill Group 3 &${b_v3_m0}${st_v3_m0}&${b_v3_m1}${st_v3_m1}&${b_v3_m2}${st_v3_m2}&${b_v3_m3}${st_v3_m3}&${b_v3_m4}${st_v3_m4}&${b_v3_m5}${st_v3_m5}&${b_v3_m6}${st_v3_m6}&${b_v3_m7}${st_v3_m7}&${b_v3_m8}${st_v3_m8}&${b_v3_m9}${st_v3_m9}&${b_v3_m10}${st_v3_m10}\\
tex 		      & (${se_v3_m0})	      & (${se_v3_m1})	   	& (${se_v3_m2})	      & (${se_v3_m3})	    & (${se_v3_m4})	      & (${se_v3_m5})	   	& (${se_v3_m6})	   	  & (${se_v3_m7})  & (${se_v3_m8})  & (${se_v3_m9})	 & (${se_v3_m10})	   	\\ \addlinespace
tex Occup Skill Group 4 &${b_v4_m0}${st_v4_m0}&${b_v4_m1}${st_v4_m1}&${b_v4_m2}${st_v4_m2}&${b_v4_m3}${st_v4_m3}&${b_v4_m4}${st_v4_m4}&${b_v4_m5}${st_v4_m5}&${b_v4_m6}${st_v4_m6}&${b_v4_m7}${st_v4_m7}&${b_v4_m8}${st_v4_m8}&${b_v4_m9}${st_v4_m9}&${b_v4_m10}${st_v4_m10}\\
tex 		      & (${se_v4_m0})	      & (${se_v4_m1})	   	& (${se_v4_m2})	      & (${se_v4_m3})	    & (${se_v4_m4})	      & (${se_v4_m5})	   	& (${se_v4_m6})	   	  & (${se_v4_m7})  & (${se_v4_m8})  & (${se_v4_m9})	  & (${se_v4_m10})	   	\\ \addlinespace
tex Occup Skill Group 5 &${b_v5_m0}${st_v5_m0}&${b_v5_m1}${st_v5_m1}&${b_v5_m2}${st_v5_m2}&${b_v5_m3}${st_v5_m3}&${b_v5_m4}${st_v5_m4}&${b_v5_m5}${st_v5_m5}&${b_v5_m6}${st_v5_m6}&${b_v5_m7}${st_v5_m7}&${b_v5_m8}${st_v5_m8}&${b_v5_m9}${st_v5_m9}&${b_v5_m10}${st_v5_m10}\\
tex 		      & (${se_v5_m0})	      & (${se_v5_m1})	   	& (${se_v5_m2})	      & (${se_v5_m3})	    & (${se_v5_m4})	      & (${se_v5_m5})	   	& (${se_v5_m6})	   	  & (${se_v5_m7})  & (${se_v5_m8})  & (${se_v5_m9})	  & (${se_v5_m10})	   	\\ \addlinespace
tex \midrule \addlinespace
tex Under-Employed   &${b_v6_m0}${st_v6_m0}&${b_v6_m1}${st_v6_m1}&${b_v6_m2}${st_v6_m2}&${b_v6_m3}${st_v6_m3}&${b_v6_m4}${st_v6_m4}&${b_v6_m5}${st_v6_m5}&${b_v6_m6}${st_v6_m6}&${b_v6_m7}${st_v6_m7}&${b_v6_m8}${st_v6_m8}&${b_v6_m9}${st_v6_m9}&${b_v6_m10}${st_v6_m10}\\
tex 		    	  & (${se_v6_m0})	    & (${se_v6_m1})	   	  & (${se_v6_m2})	    & (${se_v6_m3})	      & (${se_v6_m4})	    & (${se_v6_m5})	   	  & (${se_v6_m6})	    & (${se_v6_m7})	 & (${se_v6_m8})  & (${se_v6_m9})& (${se_v6_m10})  	\\ \addlinespace
tex \midrule \addlinespace
tex Formal Salaried &${b_v7_m0}${st_v7_m0}&${b_v7_m1}${st_v7_m1}&${b_v7_m2}${st_v7_m2}&${b_v7_m3}${st_v7_m3}&${b_v7_m4}${st_v7_m4}&${b_v7_m5}${st_v7_m5}&${b_v7_m6}${st_v7_m6}&${b_v7_m7}${st_v7_m7}&${b_v7_m8}${st_v7_m8}&${b_v7_m9}${st_v7_m9}&${b_v7_m10}${st_v7_m10}\\
tex 		    	  & (${se_v7_m0})	    & (${se_v7_m1})	   	  & (${se_v7_m2})	    & (${se_v7_m3})	      & (${se_v7_m4})	    & (${se_v7_m5})	   	  & (${se_v7_m6})	    & (${se_v7_m7})	 & (${se_v7_m8})  & (${se_v7_m9}) & (${se_v7_m10})  	\\ \addlinespace
tex Informal Salaried       &${b_v8_m0}${st_v8_m0}&${b_v8_m1}${st_v8_m1}&${b_v8_m2}${st_v8_m2}&${b_v8_m3}${st_v8_m3}&${b_v8_m4}${st_v8_m4}&${b_v8_m5}${st_v8_m5}&${b_v8_m6}${st_v8_m6}&${b_v8_m7}${st_v8_m7}&${b_v8_m8}${st_v8_m8}&${b_v8_m9}${st_v8_m9}&${b_v8_m10}${st_v8_m10}\\
tex 		    	  & (${se_v8_m0})	    & (${se_v8_m1})	   	  & (${se_v8_m2})	    & (${se_v8_m3})	      & (${se_v8_m4})	    & (${se_v8_m5})	   	  & (${se_v8_m6})	    & (${se_v8_m7})	 & (${se_v8_m8}) & (${se_v8_m9}) & (${se_v8_m10})   	\\ \addlinespace
tex Own-Account          &${b_v9_m0}${st_v9_m0}&${b_v9_m1}${st_v9_m1}&${b_v9_m2}${st_v9_m2}&${b_v9_m3}${st_v9_m3}&${b_v9_m4}${st_v9_m4}&${b_v9_m5}${st_v9_m5}&${b_v9_m6}${st_v9_m6}&${b_v9_m7}${st_v9_m7}&${b_v9_m8}${st_v9_m8}&${b_v9_m9}${st_v9_m9}&${b_v9_m10}${st_v9_m10}\\
tex 		    	  & (${se_v9_m0})	    & (${se_v9_m1})	   	  & (${se_v9_m2})	    & (${se_v9_m3})	      & (${se_v9_m4})	    & (${se_v9_m5})	   	  & (${se_v9_m6})	    & (${se_v9_m7})	 & (${se_v9_m8}	 & (${se_v9_m9})& (${se_v9_m10})  	\\ \addlinespace
tex Employer          &${b_v10_m0}${st_v10_m0}&${b_v10_m1}${st_v10_m1}&${b_v10_m2}${st_v10_m2}&${b_v10_m3}${st_v10_m3}&${b_v10_m4}${st_v10_m4}&${b_v10_m5}${st_v10_m5}&${b_v10_m6}${st_v10_m6}&${b_v10_m7}${st_v10_m7}&${b_v10_m8}${st_v10_m8}&${b_v10_m9}${st_v10_m9}&${b_v10_m10}${st_v10_m10}\\
tex 		    	  & (${se_v10_m0})	    & (${se_v10_m1})	   	  & (${se_v10_m2})	    & (${se_v10_m3})	      & (${se_v10_m4})	    & (${se_v10_m5})	   	  & (${se_v10_m6})	    & (${se_v10_m7})	 & (${se_v10_m8}	 & (${se_v10_m9})& (${se_v10_m10})  	\\ \addlinespace
tex \midrule \addlinespace
tex Kleibergen-Paap Wald Stat. & ${F_v1_m0} & ${F_v1_m1} & ${F_v1_m2} & ${F_v1_m3} & ${F_v1_m4} & ${F_v1_m5} & ${F_v1_m6} & ${F_v1_m7} & ${F_v1_m8} & ${F_v1_m9} & ${F_v1_m10} \\
tex Number of metro areas	   & ${M_v1_m0} & ${M_v1_m1} & ${M_v1_m2} & ${M_v1_m3} & ${M_v1_m4} & ${M_v1_m5} & ${M_v1_m6} & ${M_v1_m7} & ${M_v1_m8} & ${M_v1_m9} & ${M_v1_m10} \\
tex \bottomrule \bottomrule
tex \end{tabular}
tex \begin{tablenotes}
tex \small
tex \item Outcomes are multiplied by 100. All models are 2SLS linear probability models for probability of employment in a group, not conditional on working, with Year FE and City FE. Observations weighted by city-year-group population. See paper for description of robustness checks. Cluster-robust standard errors in parentheses. * p$<$0.10, ** p$<$0.05, *** p$<$0.01.
tex \end{tablenotes}
tex \end{threeparttable}
texdoc close
