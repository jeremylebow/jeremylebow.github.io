

use "$mydir/data/geih_metro_collapse.dta", clear

* ------------------------------------------------------
* --------------------- TABLE 6 ------------------------
* ------------------------------------------------------

macro define lbl    "All"
macro define lbl_m0 "Female"
macro define lbl_m1 "Male"
macro define lbl_e1 "Less than Secondary"
macro define lbl_e2 "Secondary"
macro define lbl_e3 "Post-Secondary"
macro define lbl_a1 "Age 15-24"
macro define lbl_a2 "Age 25-34"
macro define lbl_a3 "Age 35-44"
macro define lbl_a4 "Age 45-54"
macro define lbl_a5 "Age 55-64"

foreach g in "" "_m0" "_m1" "_e1" "_e2" "_e3" "_a1" "_a2" "_a3" "_a4" "_a5" {
local v=0
foreach var of varlist mig_5yr_out_sh mig_5yr_in_sh {
	local v = `v'+1
	qui sum `var'`g' [aw=pop_5yr`g']
	global m_`v'`g': di %6.2fc `r(mean)'
	* OLS
	qui reg `var'`g' ven_5yr_sh i.metro i.year [aw=pop_5yr`g'], cluster(metro)
		global N0_`v'`g': di %6.0gc e(N)
		global b0_`v'`g': di %6.2fc _b[ven_5yr_sh]
		global se0_`v'`g': di %6.2fc _se[ven_5yr_sh]
		qui test ven_5yr_sh = 0
		global p0_`v'`g': di %6.3fc r(p)
		global st0_`v'`g'=cond(${p0_`v'`g'}<.01,"***",cond(${p0_`v'`g'}<.05,"**",cond(${p0_`v'`g'}<.1,"*","")))
	* IV
	qui ivreg2 `var'`g' (ven_5yr_sh = iv_ven05) i.metro i.year [aw=pop_5yr`g'], cluster(metro) partial(i.metro i.year)
		global N_`v'`g': di %6.0gc e(N)
		global b_`v'`g': di %6.2fc _b[ven_5yr_sh]
		global se_`v'`g': di %6.2fc _se[ven_5yr_sh]
		qui test ven_5yr_sh = 0
		global p_`v'`g': di %6.3fc r(p)
		global st_`v'`g'=cond(${p_`v'`g'}<.01,"***",cond(${p_`v'`g'}<.05,"**",cond(${p_`v'`g'}<.1,"*","")))
		global F_`v'`g': di %6.2fc e(widstat)
		}
	}

texdoc init "$mydir/output/table6.tex", replace force
tex \begin{threeparttable}
tex \setlength\extrarowheight{-5pt}
tex \begin{tabular}{lccccccc}
tex \toprule \toprule
tex & (1) & (2) & (3) & (4) & (5) & (6) & (7) \\
tex &\multicolumn{3}{c}{\textbf\underline{{Out-Migration}}}&\multicolumn{3}{c}{\textbf\underline{{In-Migration}}}& \\ \addlinespace
tex & OLS & 2SLS & Sample Mean & OLS & 2SLS & Sample Mean & K-P Stat. \\ \midrule
tex  ${lbl}    &${b0_1}${st0_1}&${b_1}${st_1}&${m_1}&${b0_2}${st0_2}&${b_2}${st_2}&${m_2}&${F_1} \\
tex  		   &(${se0_1}) 	   &(${se_1}) 	 & 		&(${se0_2}) 	&(${se_2}) 	  & 	 & 		 \\
tex \addlinespace \midrule \addlinespace
tex  ${lbl_m1} &${b0_1_m1}${st0_1_m1}&${b_1_m1}${st_1_m1}&${m_1_m1}&${b0_2_m1}${st0_2_m1}&${b_2_m1}${st_2_m1}&${m_2_m1}&${F_1_m1} \\
tex  		   &(${se0_1_m1}) 		 &(${se_1_m1}) 		 & 		   &(${se0_2_m1}) 		 &(${se_2_m1}) 	 	 & 		   & 		  \\
tex  ${lbl_m0} &${b0_1_m0}${st0_1_m0}&${b_1_m0}${st_1_m0}&${m_1_m0}&${b0_2_m0}${st0_2_m0}&${b_2_m0}${st_2_m0}&${m_2_m0}&${F_1_m0} \\
tex  		   &(${se0_1_m0}) 		 &(${se_1_m0}) 		 & 		   &(${se0_2_m0}) 		 &(${se_2_m0}) 	 	 & 		   & 		  \\
tex \addlinespace \midrule \addlinespace
tex  ${lbl_a1} &${b0_1_a1}${st0_1_a1}&${b_1_a1}${st_1_a1}&${m_1_a1}&${b0_2_a1}${st0_2_a1}&${b_2_a1}${st_2_a1}&${m_2_a1}&${F_1_a1} \\
tex  		   &(${se0_1_a1}) 		 &(${se_1_a1}) 		 & 		   &(${se0_2_a1}) 		 &(${se_2_a1}) 	 	 & 		   & 		  \\
tex  ${lbl_a2} &${b0_1_a2}${st0_1_a2}&${b_1_a2}${st_1_a2}&${m_1_a2}&${b0_2_a2}${st0_2_a2}&${b_2_a2}${st_2_a2}&${m_2_a2}&${F_1_a2} \\
tex  		   &(${se0_1_a2}) 		 &(${se_1_a2}) 		 & 		   &(${se0_2_a2}) 		 &(${se_2_a2}) 	 	 & 		   & 		  \\
tex  ${lbl_a3} &${b0_1_a3}${st0_1_a3}&${b_1_a3}${st_1_a3}&${m_1_a3}&${b0_2_a3}${st0_2_a3}&${b_2_a3}${st_2_a3}&${m_2_a3}&${F_1_a3} \\
tex  		   &(${se0_1_a3}) 		 &(${se_1_a3}) 		 & 		   &(${se0_2_a3}) 		 &(${se_2_a3}) 	 	 & 		   & 		  \\
tex  ${lbl_a4} &${b0_1_a4}${st0_1_a4}&${b_1_a4}${st_1_a4}&${m_1_a4}&${b0_2_a4}${st0_2_a4}&${b_2_a4}${st_2_a4}&${m_2_a4}&${F_1_a4} \\
tex  		   &(${se0_1_a4}) 		 &(${se_1_a4}) 		 & 		   &(${se0_2_a4}) 		 &(${se_2_a4}) 	 	 & 		   & 		  \\
tex  ${lbl_a5} &${b0_1_a5}${st0_1_a5}&${b_1_a5}${st_1_a5}&${m_1_a5}&${b0_2_a5}${st0_2_a5}&${b_2_a5}${st_2_a5}&${m_2_a5}&${F_1_a5} \\
tex  		   &(${se0_1_a5}) 		 &(${se_1_a5}) 		 & 		   &(${se0_2_a5}) 		 &(${se_2_a5}) 	 	 & 		   & 		  \\
tex \addlinespace \midrule \addlinespace
tex  ${lbl_e1} &${b0_1_e1}${st0_1_e1}&${b_1_e1}${st_1_e1}&${m_1_e1}&${b0_2_e1}${st0_2_e1}&${b_2_e1}${st_2_e1}&${m_2_e1}&${F_1_e1} \\
tex  		   &(${se0_1_e1}) 		 &(${se_1_e1}) 		 & 		   &(${se0_2_e1}) 		 &(${se_2_e1}) 	 	 & 		   & 		  \\
tex  ${lbl_e2} &${b0_1_e2}${st0_1_e2}&${b_1_e2}${st_1_e2}&${m_1_e2}&${b0_2_e2}${st0_2_e2}&${b_2_e2}${st_2_e2}&${m_2_e2}&${F_1_e2} \\
tex  		   &(${se0_1_e2}) 		 &(${se_1_e2}) 		 & 		   &(${se0_2_e2}) 		 &(${se_2_e2}) 	 	 & 		   & 		  \\
tex  ${lbl_e3} &${b0_1_e3}${st0_1_e3}&${b_1_e3}${st_1_e3}&${m_1_e3}&${b0_2_e3}${st0_2_e3}&${b_2_e3}${st_2_e3}&${m_2_e3}&${F_1_e3} \\
tex  		   &(${se0_1_e3}) 		 &(${se_1_e3}) 		 & 		   &(${se0_2_e3}) 		 &(${se_2_e3}) 	 	 & 		   & 		  \\
tex \bottomrule \bottomrule
tex \end{tabular}
tex \begin{tablenotes}
tex \small
tex \item Sample includes 2014 and 2019. In- and out-migration rates taken as a share of 5-year lag population and multiplied by 100. All models include Year FE and City FE. Obsevations weighted by city-year-group population. Cluster-robust standard errors in parentheses. * p$<$0.10, ** p$<$0.05, *** p$<$0.01.
tex \end{tablenotes}
tex \end{threeparttable}
texdoc close

* ------------------------------------------------------
* -------------- TABLE A9 - ROBUSTNESS -----------------
* ------------------------------------------------------

macro define lbl_m01 "Original 2SLS"
macro define lbl_m02 ""
macro define lbl_m03 ""
macro define lbl_m11 "Drop $<$100km"
macro define lbl_m12 "from Border"
macro define lbl_m13 ""
macro define lbl_m21 "Control"
macro define lbl_m22 "Trade with"
macro define lbl_m23 "Venezuela"
macro define lbl_m31 "Year Trend X"
macro define lbl_m32 "Inv Distance"
macro define lbl_m33 "to Border"
macro define lbl_m41 "Year Trend X"
macro define lbl_m42 "Region"
macro define lbl_m43 ""
macro define lbl_m51 "Drop"
macro define lbl_m52 "Bogotá"
macro define lbl_m53 ""
macro define lbl_m61 "Drop Metro"
macro define lbl_m62 "Yrly Sample"
macro define lbl_m63 "$<$1,000"
macro define lbl_m71 "Kronmal"
macro define lbl_m72 "Specification"
macro define lbl_m73 ""

macro define m0 "" //Original
macro define m1 "if dist_km_border_crossings>100" //No within 100km of border
macro define m2 "imp_ven exp_ven" //Control imports/exports
macro define m3 "yearXinvdist" //Border distance quintile X Year trend
macro define m4 "r_*Xyear" //Border distance quintile X Year trend
macro define m5 "if metro!=11001" //No Bogota
macro define m6 "if pop14>1000" //Increase SS restriction to min 1,000-year
macro define m7 "year*Xpop14" //Kronmal - controlling flexibly for yearXpop14

foreach m in "m0" "m1" "m2" "m3" "m4" "m5" "m6" "m7" {

	if "`m'"=="m7" {
		replace ven_5yr_sh = ven_5yr/100
		}

	local v=0
	foreach var of varlist mig_5yr_out_sh mig_5yr_in_sh {
		local v = `v'+1
		
		foreach g in "" "_e1" "_e2" "_e3" {
		
		qui ivreg2 `var'`g' (ven_5yr_sh = iv_ven05) i.metro i.year ${`m'} [aw=pop_5yr`g'], cluster(metro) partial(i.metro i.year)
			global N_v`v'_`m'`g': di %6.0gc e(N)
			global M_v`v'_`m'`g': di %6.0gc e(N_clust)
			global b_v`v'_`m'`g': di %6.2fc _b[ven_5yr_sh]
			global se_v`v'_`m'`g': di %6.2fc _se[ven_5yr_sh]	
			qui test ven_5yr_sh = 0
			global p_v`v'_`m'`g': di %6.3fc r(p)
			global st_v`v'_`m'`g'=cond(${p_v`v'_`m'`g'}<.01,"***",cond(${p_v`v'_`m'`g'}<.05,"**",cond(${p_v`v'_`m'`g'}<.1,"*","")))
			global F_v`v'_`m'`g': di %6.2fc e(widstat)
			
			}
		}
		}

texdoc init "$mydir/output/tableA9.tex", replace force
tex \begin{threeparttable}
tex \setlength\extrarowheight{-5pt}
tex \begin{tabular}{lcccccccc}
tex \toprule \toprule
tex & (1) & (2) & (3) & (4) & (5) & (6) & (7) & (8) \\ \addlinespace
tex & $lbl_m01 & $lbl_m11 & $lbl_m21 & $lbl_m31 & $lbl_m41 & $lbl_m51 & $lbl_m61 & $lbl_m71 \\
tex & $lbl_m02 & $lbl_m12 & $lbl_m22 & $lbl_m32 & $lbl_m42 & $lbl_m52 & $lbl_m62 & $lbl_m72 \\
tex & $lbl_m03 & $lbl_m13 & $lbl_m23 & $lbl_m33 & $lbl_m43 & $lbl_m53 & $lbl_m63 & $lbl_m73 \\ \addlinespace \midrule
tex & \multicolumn{8}{c}{\textbf{\underline{Out-Migration}}} \\ \addlinespace
foreach g in "" "_e1" "_e2" "_e3" {
	tex ${lbl`g'}&${b_v1_m0`g'}${st_v1_m0`g'}&${b_v1_m1`g'}${st_v1_m1`g'}&${b_v1_m2`g'}${st_v1_m2`g'}&${b_v1_m3`g'}${st_v1_m3`g'}&${b_v1_m4`g'}${st_v1_m4`g'}&${b_v1_m5`g'}${st_v1_m5`g'}&${b_v1_m6`g'}${st_v1_m6`g'}&${b_v1_m7`g'}${st_v1_m7`g'}\\
	tex 		 & (${se_v1_m0`g'})	      	 & (${se_v1_m1`g'})	   	  	 & (${se_v1_m2`g'})	      	 & (${se_v1_m3`g'})	      	 & (${se_v1_m4`g'})& (${se_v1_m5`g'})& (${se_v1_m6`g'})& (${se_v1_m7`g'})	      	 \\ \addlinespace
	}
tex \midrule \addlinespace
tex & \multicolumn{8}{c}{\textbf{\underline{In-Migration}}} \\ \addlinespace
foreach g in "" "_e1" "_e2" "_e3" {
	tex ${lbl`g'}&${b_v2_m0`g'}${st_v2_m0`g'}&${b_v2_m1`g'}${st_v2_m1`g'}&${b_v2_m2`g'}${st_v2_m2`g'}&${b_v2_m3`g'}${st_v2_m3`g'}&${b_v2_m4`g'}${st_v2_m4`g'}&${b_v2_m5`g'}${st_v2_m5`g'}&${b_v2_m6`g'}${st_v2_m6`g'}&${b_v2_m7`g'}${st_v2_m7`g'}\\
	tex 		 & (${se_v2_m0`g'})	      	 & (${se_v2_m1`g'})	   	  	 & (${se_v2_m2`g'})	      	 & (${se_v2_m3`g'})	      	 & (${se_v2_m4`g'}) & (${se_v2_m5`g'}) & (${se_v2_m6`g'}) & (${se_v2_m7`g'})	      	 \\ \addlinespace
	}
tex \midrule \addlinespace
tex Kleibergen-Paap Wald Stat. & ${F_v1_m0} & ${F_v1_m1} & ${F_v1_m2} & ${F_v1_m3} & ${F_v1_m4} & ${F_v1_m5} & ${F_v1_m6} & ${F_v1_m7} \\
tex Number of metro areas	   & ${M_v1_m0} & ${M_v1_m1} & ${M_v1_m2} & ${M_v1_m3} & ${M_v1_m4} & ${M_v1_m5} & ${M_v1_m6} & ${M_v1_m7} \\
tex \bottomrule \bottomrule
tex \end{tabular}
tex \begin{tablenotes}
tex \small
tex \item Sample includes 2014 and 2019. Migration rates taken as a share of 5-year lag population. All models include Year FE and City FE. Obsevations weighted by city-year-group population. See paper for description of robustness checks. Cluster-robust standard errors in parentheses. * p$<$0.10, ** p$<$0.05, *** p$<$0.01.
tex \end{tablenotes}
tex \end{threeparttable}
texdoc close
