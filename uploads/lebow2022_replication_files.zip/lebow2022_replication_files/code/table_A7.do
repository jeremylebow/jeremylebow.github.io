

use "$mydir/data/geih_metro_collapse.dta", clear

gen ven_5yr_sh2 = ven_5yr_sh^2
gen iv_ven052 = iv_ven05^2

macro define lbl    "All"
macro define lbl_e1 "Less than Secondary"
macro define lbl_e2 "Secondary"
macro define lbl_e3 "Post-Secondary"

foreach g in "" "_e1" "_e2" "_e3" {
	qui ivreg2 ln_wage_res`g' (ven_5yr_sh ven_5yr_sh2 = iv_ven05 iv_ven052) i.metro i.year [aw=pop_work`g'], cluster(metro) endog(ven_5yr_sh) partial(i.metro i.year)
		global N`g': di %6.0gc e(N)
		global F`g': di %6.2fc e(widstat)
		global b1`g': di %6.2fc _b[ven_5yr_sh]
		global b2`g': di %6.2fc _b[ven_5yr_sh2]
		global se1`g': di %6.2fc _se[ven_5yr_sh]			
		global se2`g': di %6.2fc _se[ven_5yr_sh2]
		qui test ven_5yr_sh = 0
		global p1`g': di %6.3fc r(p)
		global st1`g'=cond(${p1`g'}<.01,"***",cond(${p1`g'}<.05,"**",cond(${p1`g'}<.1,"*","")))
		qui test ven_5yr_sh2 = 0
		global p2`g': di %6.3fc r(p)
		global st2`g'=cond(${p2`g'}<.01,"***",cond(${p2`g'}<.05,"**",cond(${p2`g'}<.1,"*","")))
		qui test ven_5yr_sh ven_5yr_sh2
		global joint`g': di %6.2fc r(chi2)		
		}

texdoc init "$mydir/output/tableA7.tex", replace force
tex \begin{threeparttable}
tex \setlength\extrarowheight{-5pt}
tex \begin{tabular}{lcccc}
tex \toprule \toprule
tex & (1) & (2) & (3) & (4) \\ \addlinespace
tex & \multicolumn{4}{c}{\textbf{\underline{Ln(Hrly Wage)}}} \\ \addlinespace
tex & ${lbl} & ${lbl_e1} & ${lbl_e2} & ${lbl_e3} \\ \addlinespace \midrule
tex Migrant Share     & ${b1}${st1} & ${b1_e1}${st1_e1} & ${b1_e2}${st1_e2} & ${b1_e3}${st1_e3} \\
tex  		          & (${se1}) 	& (${se1_e1}) 	    & (${se1_e2}) 	    & (${se1_e3}) 	    \\ \addlinespace
tex Migrant Share$^2$ & ${b2}${st2} & ${b2_e1}${st2_e1} & ${b2_e2}${st2_e2} & ${b2_e3}${st2_e3} \\
tex  		          & (${se2}) 	& (${se2_e1}) 	    & (${se2_e2}) 	    & (${se2_e3}) 	    \\ \addlinespace
tex Joint F-Statistic & ${joint}    & ${joint_e1}		& ${joint_e2}		& ${joint_e3}		\\ \addlinespace \midrule
tex Kleibergen-Paap Wald Stat.   & ${F}        & ${F_e1}		& ${F_e2}		& ${F_e3}			\\
tex \bottomrule \bottomrule
tex \end{tabular}
tex \begin{tablenotes}
tex \small
tex \item Linear and quadratic migrant shares are instrumented with a linear and quadratic of the IV. Wages are residualized and multiplied by 100. All models include Year FE and City FE. Observations weighted by city-year-group population. Cluster-robust standard errors in parentheses. * p$<$0.10, ** p$<$0.05, *** p$<$0.01.
tex \end{tablenotes}
tex \end{threeparttable}
texdoc close

