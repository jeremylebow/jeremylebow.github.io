
use "$mydir/data/geih_metro_collapse.dta", clear

macro define outcome_list "ln_wage_res ln_hrs_res unemp_res lfp_res"

label var ln_wage_res "Ln(Hrly Wage)"
label var ln_hrs_res "Ln(Hrs per Week)"
label var unemp_res "Unemployment"
label var lfp_res "Labor Force Participation"

* ------------------------------------------------
* ------------------ TABLE 1 ---------------------
* ------------------------------------------------

local v=0
foreach var of varlist $outcome_list {
	local v = `v'+1
	global lbl_`v': var label `var'

	if "`var'"=="ln_wage_res" | "`var'"=="ln_hrs_res" {
		local pop = "pop_work"
	}
	else if "`var'"=="unemp_res" {
		local pop = "pop_lfp"
	}
	else if "`var'"=="lfp_res" {
		local pop = "pop"
	}
	
	* OLS
	qui reg `var' ven_5yr_sh i.metro i.year [aw=`pop'], cluster(metro)
		global N_ols_`v': di %6.0gc e(N)
		global b_ols_`v': di %6.2fc _b[ven_5yr_sh]
		global se_ols_`v': di %6.2fc _se[ven_5yr_sh]			
		qui test ven_5yr_sh = 0
		global p_ols_`v': di %6.3fc r(p)
		global st_ols_`v'=cond(${p_ols_`v'}<.01,"***",cond(${p_ols_`v'}<.05,"**",cond(${p_ols_`v'}<.1,"*","")))
	* IV
	qui ivreg2 `var' (ven_5yr_sh = iv_ven05) i.metro i.year [aw=`pop'], cluster(metro) endog(ven_5yr_sh) partial(i.metro i.year)
		global N_iv_`v': di %6.0gc e(N)
		global b_iv_`v': di %6.2fc _b[ven_5yr_sh]
		global se_iv_`v': di %6.2fc _se[ven_5yr_sh]
		qui test ven_5yr_sh = 0
		global p_iv_`v': di %6.3fc r(p)
		global st_iv_`v'=cond(${p_iv_`v'}<.01,"***",cond(${p_iv_`v'}<.05,"**",cond(${p_iv_`v'}<.1,"*","")))
		global F_iv_`v': di %6.2fc e(widstat) //kleibergen-paap
		global H_`v': di %6.3fc e(estatp) //Hausman p-val
	}

texdoc init "$mydir/output/table1.tex", replace force
tex \begin{threeparttable}
tex \setlength\extrarowheight{-5pt}
tex \begin{tabular}{lc@{\hskip .5in}c@{\hskip .3in}c}
tex \toprule \toprule
tex & (1) & (2) & (3) \\
tex & OLS & 2SLS & Test (1)=(2) \\
tex & 	  & 	 & (p-val) \\ \midrule
foreach v of numlist 1/4 { //looping through 4 outcomes
tex  ${lbl_`v'} & ${b_ols_`v'}${st_ols_`v'} & ${b_iv_`v'}${st_iv_`v'} & ${H_`v'} \\
tex  		    & (${se_ols_`v'})			& (${se_iv_`v'})  		  &		     \\ \addlinespace \midrule
	}
tex Kleibergen-Paap Wald Stat. & & ${F_iv_1} & \\
tex N				    & ${N_ols_1} & ${N_iv_1} & \\
tex Year FE, City FE    & X			 & X		 & \\
tex \bottomrule \bottomrule
tex \end{tabular}
tex \begin{tablenotes}
tex \small
tex \item Outcomes are residualized and multiplied by 100. Observations weighted by city-year population. Column 3 presents a Hausman test for endogenous regressors with robust standard errors. Cluster-robust standard errors in parentheses. * p$<$0.10, ** p$<$0.05, *** p$<$0.01.
tex \end{tablenotes}
tex \end{threeparttable}
texdoc close

* -----------------------------------------------------------------------
* ------------------ TABLE 2 - By demographic group ---------------------
* -----------------------------------------------------------------------

macro define lbl    "All"
macro define lbl_m0 "Female"
macro define lbl_m1 "Male"
macro define lbl_e1 "Less than Secondary"
macro define lbl_e2 "Secondary"
macro define lbl_e3 "Post-Secondary"
macro define lbl_a1 "Age 15-24"
macro define lbl_a2 "Age 25-34"
macro define lbl_a3 "Age 35-44"
macro define lbl_a4 "Age 45-54"
macro define lbl_a5 "Age 55-64"

foreach g in "" "_m0" "_m1" "_e1" "_e2" "_e3" "_a1" "_a2" "_a3" "_a4" "_a5" {
local v=0
foreach var of varlist $outcome_list {
	local v = `v'+1
	
	if "`var'"=="ln_wage_res" | "`var'"=="ln_hrs_res" {
		local pop = "pop_work"
	}
	else if "`var'"=="unemp_res" {
		local pop = "pop_lfp"
	}
	else if "`var'"=="lfp_res" {
		local pop = "pop"
	}
		
	qui ivreg2 `var'`g' (ven_5yr_sh = iv_ven05) i.metro i.year [aw=`pop'`g'], cluster(metro) endog(ven_5yr_sh) partial(i.metro i.year)
		global N_`v'`g': di %6.0gc e(N)
		global b_`v'`g': di %6.2fc _b[ven_5yr_sh]
		global se_`v'`g': di %6.2fc _se[ven_5yr_sh]			
		qui test ven_5yr_sh = 0
		global p_`v'`g': di %6.3fc r(p)
		global st_`v'`g'=cond(${p_`v'`g'}<.01,"***",cond(${p_`v'`g'}<.05,"**",cond(${p_`v'`g'}<.1,"*","")))
		global F_`v'`g': di %6.2fc e(widstat)
		}
	}

texdoc init "$mydir/output/table2.tex", replace force
tex \begin{threeparttable}
tex \setlength\extrarowheight{-5pt}
tex \begin{tabular}{lccc@{\hskip .3in}cc}
tex \toprule \toprule
tex & (1) & (2) & (3) & (4) & (5) \\
tex & Ln(Hrly Wage) & Ln(Hrs per week) & Unemployment & LFP & K-P Wald Stat. \\ \midrule
tex  ${lbl}    & ${b_1}${st_1} 		 & ${b_2}${st_2} 	   & ${b_3}${st_3}		 & ${b_4}${st_4} 	   & ${F_1}\\
tex  		   & (${se_1}) 		 	 & (${se_2}) 	       & (${se_3}) 		 	 & (${se_4}) 	  	   & \\
tex \addlinespace \midrule \addlinespace
tex  ${lbl_m1} & ${b_1_m1}${st_1_m1} & ${b_2_m1}${st_2_m1} & ${b_3_m1}${st_3_m1} & ${b_4_m1}${st_4_m1} & ${F_1_m1}\\
tex  		   & (${se_1_m1}) 		 & (${se_2_m1}) 	   & (${se_3_m1}) 		 & (${se_4_m1}) 	   & \\
tex  ${lbl_m0} & ${b_1_m0}${st_1_m0} & ${b_2_m0}${st_2_m0} & ${b_3_m0}${st_3_m0} & ${b_4_m0}${st_4_m0} & ${F_1_m0}\\
tex  		   & (${se_1_m0}) 		 & (${se_2_m0}) 	   & (${se_3_m0}) 		 & (${se_4_m0}) 	   & \\ 
tex \addlinespace \midrule \addlinespace
tex  ${lbl_a1} & ${b_1_a1}${st_1_a1} & ${b_2_a1}${st_2_a1} & ${b_3_a1}${st_3_a1} & ${b_4_a1}${st_4_a1} & ${F_1_a1}\\
tex  		   & (${se_1_a1}) 		 & (${se_2_a1}) 	   & (${se_3_a1}) 		 & (${se_4_a1}) 	   & \\
tex  ${lbl_a2} & ${b_1_a2}${st_1_a2} & ${b_2_a2}${st_2_a2} & ${b_3_a2}${st_3_a2} & ${b_4_a2}${st_4_a2} & ${F_1_a2}\\
tex  		   & (${se_1_a2}) 		 & (${se_2_a2}) 	   & (${se_3_a2}) 		 & (${se_4_a2}) 	   & \\
tex  ${lbl_a3} & ${b_1_a3}${st_1_a3} & ${b_2_a3}${st_2_a3} & ${b_3_a3}${st_3_a3} & ${b_4_a3}${st_4_a3} & ${F_1_a3}\\
tex  		   & (${se_1_a3}) 		 & (${se_2_a3}) 	   & (${se_3_a3}) 		 & (${se_4_a3}) 	   & \\
tex  ${lbl_a4} & ${b_1_a4}${st_1_a4} & ${b_2_a4}${st_2_a4} & ${b_3_a4}${st_3_a4} & ${b_4_a4}${st_4_a4} & ${F_1_a4}\\
tex  		   & (${se_1_a4}) 		 & (${se_2_a4}) 	   & (${se_3_a4}) 		 & (${se_4_a4}) 	   & \\
tex  ${lbl_a5} & ${b_1_a5}${st_1_a5} & ${b_2_a5}${st_2_a5} & ${b_3_a5}${st_3_a5} & ${b_4_a5}${st_4_a5} & ${F_1_a5}\\
tex  		   & (${se_1_a5}) 		 & (${se_2_a5}) 	   & (${se_3_a5}) 		 & (${se_4_a5}) 	   & \\
tex \addlinespace \midrule \addlinespace
tex  ${lbl_e1} & ${b_1_e1}${st_1_e1} & ${b_2_e1}${st_2_e1} & ${b_3_e1}${st_3_e1} & ${b_4_e1}${st_4_e1} & ${F_1_e1}\\
tex  		   & (${se_1_e1}) 		 & (${se_2_e1}) 	   & (${se_3_e1}) 		 & (${se_4_e1}) 	   & \\
tex  ${lbl_e2} & ${b_1_e2}${st_1_e2} & ${b_2_e2}${st_2_e2} & ${b_3_e2}${st_3_e2} & ${b_4_e2}${st_4_e2} & ${F_1_e2}\\
tex  		   & (${se_1_e2}) 		 & (${se_2_e2}) 	   & (${se_3_e2}) 		 & (${se_4_e2}) 	   & \\
tex  ${lbl_e3} & ${b_1_e3}${st_1_e3} & ${b_2_e3}${st_2_e3} & ${b_3_e3}${st_3_e3} & ${b_4_e3}${st_4_e3} & ${F_1_e3}\\
tex  		   & (${se_1_e3}) 		 & (${se_2_e3}) 	   & (${se_3_e3}) 		 & (${se_4_e3}) 	   & \\
tex \bottomrule \bottomrule
tex \end{tabular}
tex \begin{tablenotes}
tex \small
tex \item Outcomes are residualized and multiplied by 100. All models include Year FE and City FE. Observations weighted by city-year-group population. Cluster-robust standard errors in parentheses. * p$<$0.10, ** p$<$0.05, *** p$<$0.01.
tex \end{tablenotes}
tex \end{threeparttable}
texdoc close


* -----------------------------------------------------------------------
* ------------------- TABLE 3 and A6 - Robustness -----------------------
* -----------------------------------------------------------------------

macro define lbl_m01 "Original"
macro define lbl_m02 "2SLS"
macro define lbl_m03 ""
macro define lbl_m11 "Drop $<$100km"
macro define lbl_m12 "from Border"
macro define lbl_m13 ""
macro define lbl_m21 "Control"
macro define lbl_m22 "Trade with"
macro define lbl_m23 "Venezuela"
macro define lbl_m31 "Year Trend X"
macro define lbl_m32 "Inv. Distance"
macro define lbl_m33 "to Border"
macro define lbl_m41 "Year Trend X"
macro define lbl_m42 "Region"
macro define lbl_m43 ""
macro define lbl_m51 "Year Trend X"
macro define lbl_m52 "Pre-trend"
macro define lbl_m53 ""
macro define lbl_m61 "Drop"
macro define lbl_m62 "Bogotá"
macro define lbl_m63 ""
macro define lbl_m71 "Drop Metro"
macro define lbl_m72 "Yrly Sample"
macro define lbl_m73 "$<$1,000"
macro define lbl_m81 "2014-2019"
macro define lbl_m82 "Difference"
macro define lbl_m83 "Model"
macro define lbl_m91 "Kronmal"
macro define lbl_m92 "Specification"
macro define lbl_m93 ""
macro define lbl_m101 "Assign"
macro define lbl_m102 "Natives to"
macro define lbl_m103 "Past Metro"

foreach m in "m0" "m1" "m2" "m3" "m4" "m5" "m6" "m7" "m8" "m9" "m10" {
	local v=0
	
	use "$mydir/data/geih_metro_collapse.dta", clear

	if "`m'"=="m10" {
		foreach var of varlist $outcome_list pop_work pop_lfp pop {
			replace `var'  = `var'_pastmetro
			replace `var'_e1 = `var'_pastmetro_e1
			replace `var'_e2 = `var'_pastmetro_e2
			replace `var'_e3 = `var'_pastmetro_e3
			}
		}

	if "`m'"=="m9" {	
		replace ven_5yr_sh = ven_5yr/100
		}

	if "`m'"=="m8" {
		local add = "14"
		local dif = "_dif"
		local partial = ""
		foreach var of varlist ven_5yr_sh iv_ven05 {
			gen temp = `var' if year==2014
			bysort metro: egen `var'14 = max(temp)
			drop temp
			gen temp = `var' if year==2019
			bysort metro: egen `var'19 = max(temp)
			drop temp
			gen `var'_dif = `var'19 - `var'14
			}
		foreach var of varlist $outcome_list {
			foreach g in "" "_e1" "_e2" "_e3" {
				gen temp = `var'`g' if year==2014
				bysort metro: egen `var'`g'14 = max(temp)
				drop temp
				gen temp = `var'`g' if year==2019
				bysort metro: egen `var'`g'19 = max(temp)
				drop temp
				gen `var'`g'_dif = `var'`g'19 - `var'`g'14
				}
			}
		}
	else if "`m'"!="m8" {
		local add = ""
		local dif = ""
		local partial = "partial(i.metro i.year)"
	}

	foreach var of varlist $outcome_list {
		local v = `v'+1
		foreach g in "" "_e1" "_e2" "_e3" {

		if "`var'"=="ln_wage_res" {
			local pop = "pop_work"
			local trend = "ln_wage"
		}
		else if "`var'"=="ln_hrs_res" {
			local pop = "pop_work"
			local trend = "ln_hrs"
		}
		else if "`var'"=="unemp_res" {
			local pop = "pop_lfp"
			local trend = "unemp"
		}
		else if "`var'"=="lfp_res" {
			local pop = "pop"
			local trend = "lfp"
		}

		macro define m0 "(ven_5yr_sh = iv_ven05) i.metro i.year" //Original
		macro define m1 "(ven_5yr_sh = iv_ven05) i.metro i.year if dist_km_border_crossings>100" //No within 100km of border
		macro define m2 "(ven_5yr_sh = iv_ven05) i.metro i.year imp_ven exp_ven" //Control imports/exports
		macro define m3 "(ven_5yr_sh = iv_ven05) i.metro i.year yearXinvdist" //Border distance X Year trend
		macro define m4 "(ven_5yr_sh = iv_ven05) i.metro i.year r_*Xyear" //Region X Year trend
		macro define m5 "(ven_5yr_sh = iv_ven05) i.metro i.year yearX`trend'_13_15`g'" //Pre-trend trend X Year trend
		macro define m6 "(ven_5yr_sh = iv_ven05) i.metro i.year if metro!=11001" //No Bogota
		macro define m7 "(ven_5yr_sh = iv_ven05) i.metro i.year if pop14>1000" //Increase SS restriction to min 1,000-year
		macro define m8 "(ven_5yr_sh_dif = iv_ven05_dif) if year==2019" //2014-2019 difference model
		macro define m9 "(ven_5yr_sh = iv_ven05) year*Xpop14 i.metro i.year" //Kronmal specification (ven_5yr in numbers, control pop)
		macro define m10 "(ven_5yr_sh = iv_ven05) i.metro i.year" //Past metro (same as original)

		qui ivreg2 `var'`g'`dif' ${`m'} [aw=`pop'`add'`g'], cluster(metro) `partial'
			global N_v`v'_`m'`g': di %6.0gc e(N)
			global M_v`v'_`m'`g': di %6.0gc e(N_clust)
			global b_v`v'_`m'`g': di %6.2fc _b[ven_5yr]
			global se_v`v'_`m'`g': di %6.2fc _se[ven_5yr]	
			global F_v`v'_`m'`g': di %6.2fc e(widstat)
			qui test ven_5yr = 0
			global p_v`v'_`m'`g': di %6.3fc r(p)
			global st_v`v'_`m'`g'=cond(${p_v`v'_`m'`g'}<.01,"***",cond(${p_v`v'_`m'`g'}<.05,"**",cond(${p_v`v'_`m'`g'}<.1,"*","")))
			}
		}
	}

texdoc init "$mydir/output/table3.tex", replace force
tex \begin{threeparttable}
tex \setlength\extrarowheight{-5pt}
tex \begin{tabular}{lc@{\hskip .3in}c@{\hskip .3in}c@{\hskip .3in}c@{\hskip .3in}c@{\hskip .3in}c}
tex \toprule \toprule
tex & (1) & (2) & (3) & (4) & (5) & (6) \\ \addlinespace
tex & $lbl_m01 & $lbl_m11 & $lbl_m21 & $lbl_m31 & $lbl_m41 & $lbl_m51 \\
tex & $lbl_m02 & $lbl_m12 & $lbl_m22 & $lbl_m32 & $lbl_m42 & $lbl_m52 \\
tex & $lbl_m03 & $lbl_m13 & $lbl_m23 & $lbl_m33 & $lbl_m43 & $lbl_m53 \\ \addlinespace \midrule
tex & \multicolumn{5}{c}{\textbf\underline{{Ln(Hourly Wage)}}} \\ \addlinespace
foreach g in "" "_e1" "_e2" "_e3" {
	tex ${lbl`g'}&${b_v1_m0`g'}${st_v1_m0`g'}&${b_v1_m1`g'}${st_v1_m1`g'}&${b_v1_m2`g'}${st_v1_m2`g'}&${b_v1_m3`g'}${st_v1_m3`g'}&${b_v1_m4`g'}${st_v1_m4`g'}&${b_v1_m5`g'}${st_v1_m5`g'}\\
	tex 		 & (${se_v1_m0`g'})	      	 & (${se_v1_m1`g'})	   	  	 & (${se_v1_m2`g'})	      	 & (${se_v1_m3`g'})	      	 & (${se_v1_m4`g'})	      	 & (${se_v1_m5`g'})	   	     \\ \addlinespace
	}
tex \midrule \addlinespace
tex & \multicolumn{5}{c}{\textbf\underline{{Ln(Hours per Week)}}} \\ \addlinespace
foreach g in "" "_e1" "_e2" "_e3" {
	tex ${lbl`g'}&${b_v2_m0`g'}${st_v2_m0`g'}&${b_v2_m1`g'}${st_v2_m1`g'}&${b_v2_m2`g'}${st_v2_m2`g'}&${b_v2_m3`g'}${st_v2_m3`g'}&${b_v2_m4`g'}${st_v2_m4`g'}&${b_v2_m5`g'}${st_v2_m5`g'}\\
	tex 		 & (${se_v2_m0`g'})	      	 & (${se_v2_m1`g'})	   	  	 & (${se_v2_m2`g'})	      	 & (${se_v2_m3`g'})	      	 & (${se_v2_m4`g'})	      	 & (${se_v2_m5`g'})	   	     \\ \addlinespace
	}
tex \midrule \addlinespace
tex & \multicolumn{5}{c}{\textbf\underline{{Unemployment}}} \\ \addlinespace
foreach g in "" "_e1" "_e2" "_e3" {
	tex ${lbl`g'}&${b_v3_m0`g'}${st_v3_m0`g'}&${b_v3_m1`g'}${st_v3_m1`g'}&${b_v3_m2`g'}${st_v3_m2`g'}&${b_v3_m3`g'}${st_v3_m3`g'}&${b_v3_m4`g'}${st_v3_m4`g'}&${b_v3_m5`g'}${st_v3_m5`g'}\\
	tex 		 & (${se_v3_m0`g'})	      	 & (${se_v3_m1`g'})	   	  	 & (${se_v3_m2`g'})	      	 & (${se_v3_m3`g'})	      	 & (${se_v3_m4`g'})	      	 & (${se_v3_m5`g'})	   	     \\ \addlinespace
	}
tex \midrule \addlinespace
tex & \multicolumn{5}{c}{\textbf\underline{{LFP}}} \\ \addlinespace
foreach g in "" "_e1" "_e2" "_e3" {
	tex ${lbl`g'}&${b_v4_m0`g'}${st_v4_m0`g'}&${b_v4_m1`g'}${st_v4_m1`g'}&${b_v4_m2`g'}${st_v4_m2`g'}&${b_v4_m3`g'}${st_v4_m3`g'}&${b_v4_m4`g'}${st_v4_m4`g'}&${b_v4_m5`g'}${st_v4_m5`g'}\\
	tex 		 & (${se_v4_m0`g'})	      	 & (${se_v4_m1`g'})	   	  	 & (${se_v4_m2`g'})	      	 & (${se_v4_m3`g'})	      	 & (${se_v4_m4`g'})	      	 & (${se_v4_m5`g'})	   	     \\ \addlinespace
	}
tex \midrule \addlinespace
tex Kleibergen-Paap Wald Stat.   & ${F_v1_m0} & ${F_v1_m1} & ${F_v1_m2} & ${F_v1_m3} & ${F_v1_m4} & ${F_v1_m5} \\
tex Number of metro areas		 & ${M_v1_m0} & ${M_v1_m1} & ${M_v1_m2} & ${M_v1_m3} & ${M_v1_m4} & ${M_v1_m5} \\
tex \bottomrule \bottomrule
tex \end{tabular}
tex \begin{tablenotes}
tex \small
tex \item Outcomes residualized and multiplied by 100. All models include Year FE and City FE. See text for description of robustness checks. Observations weighted by city-year-group population. Cluster-robust standard errors in parentheses. * p$<$0.10, ** p$<$0.05, *** p$<$0.01.
tex \end{tablenotes}
tex \end{threeparttable}
texdoc close

texdoc init "$mydir/output/tableA6.tex", replace force
tex \begin{threeparttable}
tex \setlength\extrarowheight{-5pt}
tex \begin{tabular}{lc@{\hskip .3in}c@{\hskip .3in}c@{\hskip .3in}c@{\hskip .3in}c@{\hskip .3in}c}
tex \toprule \toprule
tex & (1) & (2) & (3) & (4) & (5) & (6) \\ \addlinespace
tex & $lbl_m01 & $lbl_m61 & $lbl_m71 & $lbl_m81 & $lbl_m91 & $lbl_m101 \\
tex & $lbl_m02 & $lbl_m62 & $lbl_m72 & $lbl_m82 & $lbl_m92 & $lbl_m102 \\
tex & $lbl_m03 & $lbl_m63 & $lbl_m73 & $lbl_m83 & $lbl_m93 & $lbl_m103 \\ \addlinespace \midrule
tex & \multicolumn{5}{c}{\textbf\underline{{Ln(Hourly Wage)}}} \\ \addlinespace
foreach g in "" "_e1" "_e2" "_e3" {
	tex ${lbl`g'}&${b_v1_m0`g'}${st_v1_m0`g'}&${b_v1_m6`g'}${st_v1_m6`g'}&${b_v1_m7`g'}${st_v1_m7`g'}&${b_v1_m8`g'}${st_v1_m8`g'}&${b_v1_m9`g'}${st_v1_m9`g'}&${b_v1_m10`g'}${st_v1_m10`g'}\\
	tex 		 & (${se_v1_m0`g'})	      	 & (${se_v1_m6`g'})	   	  	 & (${se_v1_m7`g'})	      	 & (${se_v1_m8`g'})	      	 & (${se_v1_m9`g'})	      	 & (${se_v1_m10`g'})	   	     \\ \addlinespace
	}
tex \midrule \addlinespace
tex & \multicolumn{5}{c}{\textbf\underline{{Ln(Hours per Week)}}} \\ \addlinespace
foreach g in "" "_e1" "_e2" "_e3" {
	tex ${lbl`g'}&${b_v2_m0`g'}${st_v2_m0`g'}&${b_v2_m6`g'}${st_v2_m6`g'}&${b_v2_m7`g'}${st_v2_m7`g'}&${b_v2_m8`g'}${st_v2_m8`g'}&${b_v2_m9`g'}${st_v2_m9`g'}&${b_v2_m10`g'}${st_v2_m10`g'}\\
	tex 		 & (${se_v2_m0`g'})	      	 & (${se_v2_m6`g'})	   	  	 & (${se_v2_m7`g'})	      	 & (${se_v2_m8`g'})	      	 & (${se_v2_m9`g'})	      	 & (${se_v2_m10`g'})	   	     \\ \addlinespace
	}
tex \midrule \addlinespace
tex & \multicolumn{5}{c}{\textbf\underline{{Unemployment}}} \\ \addlinespace
foreach g in "" "_e1" "_e2" "_e3" {
	tex ${lbl`g'}&${b_v3_m0`g'}${st_v3_m0`g'}&${b_v3_m6`g'}${st_v3_m6`g'}&${b_v3_m7`g'}${st_v3_m7`g'}&${b_v3_m8`g'}${st_v3_m8`g'}&${b_v3_m9`g'}${st_v3_m9`g'}&${b_v3_m10`g'}${st_v3_m10`g'}\\
	tex 		 & (${se_v3_m0`g'})	      	 & (${se_v3_m6`g'})	   	  	 & (${se_v3_m7`g'})	      	 & (${se_v3_m8`g'})	      	 & (${se_v3_m9`g'})	      	 & (${se_v3_m10`g'})	   	     \\ \addlinespace
	}
tex \midrule \addlinespace
tex & \multicolumn{5}{c}{\textbf\underline{{LFP}}} \\ \addlinespace
foreach g in "" "_e1" "_e2" "_e3" {
	tex ${lbl`g'}&${b_v4_m0`g'}${st_v4_m0`g'}&${b_v4_m6`g'}${st_v4_m6`g'}&${b_v4_m7`g'}${st_v4_m7`g'}&${b_v4_m8`g'}${st_v4_m8`g'}&${b_v4_m9`g'}${st_v4_m9`g'}&${b_v4_m10`g'}${st_v4_m10`g'}\\
	tex 		 & (${se_v4_m0`g'})	      	 & (${se_v4_m6`g'})	   	  	 & (${se_v4_m7`g'})	      	 & (${se_v4_m8`g'})	      	 & (${se_v4_m9`g'})	      	 & (${se_v4_m10`g'})	   	     \\ \addlinespace
	}
tex \midrule \addlinespace
tex Kleibergen-Paap Wald Stat.   & ${F_v1_m0} & ${F_v1_m6} & ${F_v1_m7} & ${F_v1_m8} & ${F_v1_m9} & ${F_v1_m10} \\
tex Number of metro areas		 & ${M_v1_m0} & ${M_v1_m6} & ${M_v1_m7} & ${M_v1_m8} & ${M_v1_m9} & ${M_v1_m10} \\
tex \bottomrule \bottomrule
tex \end{tabular}
tex \begin{tablenotes}
tex \small
tex \item Outcomes are residualized and multiplied by 100. All models include Year FE and City FE. Column 4 regresses the change in outcomes from 2014-2019 on the change in the migrant share. Column 5 replaces the migrant share with the number of migrants (divided by 100) and controls for baseline population interacted with year fixed effects. Column 6 assigns natives to their 5-year lagged metro area of residence. Observations weighted by city-year-group population. Cluster-robust standard errors in parentheses. * p$<$0.10, ** p$<$0.05, *** p$<$0.01.
tex \end{tablenotes}
tex \end{threeparttable}
texdoc close



