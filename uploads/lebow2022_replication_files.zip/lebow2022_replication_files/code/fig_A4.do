

* Put together labor variables from 2010-2019
use "$mydir/data/geih_metro_collapse_2010to2015.dta", clear
drop if year>=2014
append using "$mydir/data/geih_metro_collapse.dta"
keep year metro pop14 ln_wage ln_hrs lfp unemp pop pop_work pop_lfp censo05_ven_born

* Analysis sample
keep if metro!=.
bysort metro: egen maxpop14 = max(pop14)
keep if maxpop14>300 & maxpop14!=. //also drop 5120, not in 2010-2011

* Expand censo05 to pre-2014
rename censo05_ven_born temp
bysort metro: egen censo05_ven_born = max(temp)
drop temp

* Prepare IV-year interaction
egen ivstd = std(censo05_ven_born)
foreach n of numlist 2010/2019 {
	gen iv`n' = ivstd*(year==`n')
	}
drop iv2015 //excluded group

set scheme plotplainblind

* Pretrends - wages
reg ln_wage iv* i.metro i.year [aw = pop_work], cluster(metro)
foreach y of numlist 2010/2014 2016/2019 {
	local y`y' = _b[iv`y']
	local se`y' = _se[iv`y']
	}
local y2015 = 0
local se2015 = 0
preserve
clear
set obs 10
gen x = 2009 + _n
gen y = .
gen se = .
local n = 2009
foreach y of numlist 1/10 {
	local n = `n' + 1
	replace y  = `y`n''  if x==`n'
	replace se = `se`n'' if x==`n'	
	}
gen ci_l = y - se*1.96
gen ci_u = y + se*1.96
eclplot y ci_l ci_u x, yline(0)  ///
	xlabel(2010(1)2019,val angle(45)) xtick(2010(1)2019)  ///
	xtitle("") ytitle("")  title("Ln(Hrly Wage)")
graph export "$mydir/output/figA4a.png", replace
restore

* Pretrends - hrs
reg ln_hrs iv* i.metro i.year [aw = pop_work], cluster(metro)
foreach y of numlist 2010/2014 2016/2019 {
	local y`y' = _b[iv`y']
	local se`y' = _se[iv`y']
	}
local y2015 = 0
local se2015 = 0
preserve
clear
set obs 10
gen x = 2009 + _n
gen y = .
gen se = .
local n = 2009
foreach y of numlist 1/10 {
	local n = `n' + 1
	replace y  = `y`n''  if x==`n'
	replace se = `se`n'' if x==`n'	
	}
gen ci_l = y - se*1.96
gen ci_u = y + se*1.96
eclplot y ci_l ci_u x, yline(0)  ///
	xlabel(2010(1)2019,val angle(45)) xtick(2010(1)2019)  ///
	xtitle("") ytitle("")  title("Ln(Hrs per Week)")
graph export "$mydir/output/figA4b.png", replace
restore

* Pretrends - unemployment
reg unemp iv* i.metro i.year [aw = pop_lfp], cluster(metro)
foreach y of numlist 2010/2014 2016/2019 {
	local y`y' = _b[iv`y']
	local se`y' = _se[iv`y']
	}
local y2015 = 0
local se2015 = 0
preserve
clear
set obs 10
gen x = 2009 + _n
gen y = .
gen se = .
local n = 2009
foreach y of numlist 1/10 {
	local n = `n' + 1
	replace y  = `y`n''  if x==`n'
	replace se = `se`n'' if x==`n'	
	}
gen ci_l = y - se*1.96
gen ci_u = y + se*1.96
eclplot y ci_l ci_u x, yline(0)  ///
	xlabel(2010(1)2019,val angle(45)) xtick(2010(1)2019)  ///
	xtitle("") ytitle("")  title("Unemployment Rate")
graph export "$mydir/output/figA4c.png", replace
restore

* Pretrends - LFP
reg lfp iv* i.metro i.year [aw = pop], cluster(metro)
foreach y of numlist 2010/2014 2016/2019 {
	local y`y' = _b[iv`y']
	local se`y' = _se[iv`y']
	}
local y2015 = 0
local se2015 = 0
preserve
clear
set obs 10
gen x = 2009 + _n
gen y = .
gen se = .
local n = 2009
foreach y of numlist 1/10 {
	local n = `n' + 1
	replace y  = `y`n''  if x==`n'
	replace se = `se`n'' if x==`n'	
	}
gen ci_l = y - se*1.96
gen ci_u = y + se*1.96
eclplot y ci_l ci_u x, yline(0)  ///
	xlabel(2010(1)2019,val angle(45)) xtick(2010(1)2019)  ///
	xtitle("") ytitle("")  title("Labor Force Participation")
graph export "$mydir/output/figA4d.png", replace
restore
