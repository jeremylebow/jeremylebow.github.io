

* DEFINE DIRECTORY:
macro define mydir ""

* GENERATE TABLES AND FIGURES:
do "$mydir/code/table_1_2_3_A6.do"
do "$mydir/code/table_4_5_A8.do"
do "$mydir/code/table_6_A9.do"
do "$mydir/code/table_7_A10.do"
do "$mydir/code/table_A2.do"
do "$mydir/code/table_A3_A4_A5.do"
do "$mydir/code/table_A7.do"

do "$mydir/code/fig_3_A5.do"
do "$mydir/code/fig_A3.do"
do "$mydir/code/fig_A4.do"
do "$mydir/code/fig_A6.do"
