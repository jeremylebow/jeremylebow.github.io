
* INSERT DIRECTORY:
macro define mydir ""

clear all
set maxvar 50000

* --------------------------------
* COLLAPSE By GEIH Area and Dpto
* --------------------------------

use "$mydir/data/geih_labor_microdata.dta", replace
keep if age>=15 & age<=64
keep if year>=2014

* Labor Outcomes for natives
* --------------------------------
macro define labor_collapse "ln_wage_res ln_hrs_res lfp_res unemp_res"
preserve
keep if for_5yr==0
destring dpto, replace
assert dpto!=.
collapse (count) pop pop_work pop_lfp (mean) $labor_collapse, by(dpto year)
foreach var of varlist pop pop_work pop_lfp $labor_collapse {
	rename `var' dpto_`var' 
}
tempfile dpto_overall
save `dpto_overall', replace
restore
preserve
keep if for_5yr==0
keep if area!=.
collapse (count) pop pop_work pop_lfp (mean) $labor_collapse, by(area year)
foreach var of varlist pop pop_work pop_lfp $labor_collapse {
	rename `var' area_`var' 
}
rename area dpto
tempfile area_overall
save `area_overall', replace
restore

* 2014 population
* --------------------------------
preserve
keep if year==2014
destring dpto, replace
assert dpto!=.
collapse (count) pop pop_lfp pop_work, by(dpto)
rename pop 	    dpto_pop14
rename pop_lfp  dpto_pop_lfp14
rename pop_work dpto_pop_work14
tempfile dpto_pop14
save `dpto_pop14', replace
restore
preserve
keep if year==2014
keep if area!=.
collapse (count) pop pop_lfp pop_work, by(area)
rename pop 	    area_pop14
rename pop_lfp  area_pop_lfp14
rename pop_work area_pop_work14
rename area dpto
tempfile area_pop14
save `area_pop14', replace
restore

* Migrant population
* --------------------------------

* 5-year migration measure
foreach x in dpto area {
	preserve
	destring `x', replace
	replace ven_5yr = . if ven_5yr==0
	replace for_5yr = . if for_5yr==0
	gen ven_5yr_ret0 = ven_5yr if for_born==1
	gen for_5yr_ret0 = for_5yr if for_born==1
	macro define count_varlist "ven_5yr ven_5yr_ret0 for_5yr for_5yr_ret0"
	collapse (count) $count_varlist, by(`x' year)
	foreach var of varlist $count_varlist {
		rename `var' `x'_`var'
		}
	cap rename area dpto
	drop if dpto==.
	tempfile ven_5yr_`x'
	save `ven_5yr_`x'', replace
	restore
	}

* 1-year migration measure
foreach x in dpto area {
	preserve
	destring `x', replace
	replace ven_1yr = . if ven_1yr==0
	gen ven_1yr_ret0 = ven_1yr if for_born==1
	collapse (count) ven_1yr ven_1yr_ret0, by(`x' year)
	rename ven_1yr 		`x'_ven_1yr
	rename ven_1yr_ret0 `x'_ven_1yr_ret0
	cap rename area dpto
	drop if dpto==.
	tempfile ven_1yr_`x'
	save `ven_1yr_`x'', replace
	restore
	}

* --------------------------------
* Merge together
* --------------------------------

clear all
use `dpto_overall', clear
merge 1:1 dpto year using `area_overall'
assert _merge==3 if dpto!=25
drop _merge
merge 1:1 dpto year using `dpto_pop14'
assert _merge==3
drop _merge
merge 1:1 dpto year using `area_pop14'
assert _merge==3 if dpto!=25
drop _merge
merge 1:1 dpto year using `ven_5yr_dpto'
assert _merge==3
drop _merge
merge 1:1 dpto year using `ven_5yr_area'
assert _merge==3 if dpto!=25
drop _merge
merge 1:1 dpto year using `ven_1yr_dpto'
assert _merge==3
drop _merge
merge 1:1 dpto year using `ven_1yr_area'
assert _merge==3 if dpto!=25
drop _merge
gen area = dpto if dpto!=25

* Migration shares
foreach x in dpto area {
	bysort year: egen pop14_`x'_nat = sum(`x'_pop14)
	foreach t in 1 5 {
		gen ven_`t'yr_sh_`x' = 100*(`x'_ven_`t'yr/`x'_pop14)
		bysort year: egen ven_`t'yr_`x'_nat = sum(`x'_ven_`t'yr)
		gen ven_`t'yr_sh_`x'_nat = 100*(ven_`t'yr_`x'_nat - `x'_ven_`t'yr)/(pop14_`x'_nat - `x'_pop14) //leave-out version
		}
	}
	
* Generate IV
merge m:1 dpto using "$mydir/data/censo93_collapse_dpto.dta", nogen
merge m:1 dpto using "$mydir/data/censo05_collapse_dpto.dta", nogen
merge m:1 area using "$mydir/data/censo93_collapse_area.dta", nogen
merge m:1 area using "$mydir/data/censo05_collapse_area.dta", nogen
merge m:1 dpto using "$mydir/data/traveldist_dpto.dta", nogen
label var min_dist_km "Min driving distance from capital to closest border crossing"
drop if dpto>76
foreach x in dpto area {
	gen iv_ven05_`x' = censo05_ven_born_`x' * ven_5yr_sh_`x'_nat
	gen iv_ven93_`x' = censo93_ven_born_`x' * ven_5yr_sh_`x'_nat
	gen iv_dist_`x'  = (1/min_dist_km) * ven_5yr_`x'_nat
	gen iv_ven05_`x'_1yr = censo05_ven_born_`x' * ven_1yr_sh_`x'_nat
	gen iv_ven93_`x'_1yr = censo93_ven_born_`x' * ven_1yr_sh_`x'_nat
	gen iv_dist_`x'_1yr  = (1/min_dist_km) * ven_1yr_`x'_nat
	}

* Repeat for return migrants only
foreach x in dpto area {
	foreach t in 1 5 {
		gen ven_`t'yr_sh_`x'_ret0 = 100*(`x'_ven_`t'yr_ret0/`x'_pop14)
		bysort year: egen ven_`t'yr_`x'_nat_ret0 = sum(`x'_ven_`t'yr_ret0)
		gen ven_`t'yr_sh_`x'_nat_ret0 = 100*(ven_`t'yr_`x'_nat_ret0 - `x'_ven_`t'yr_ret0)/(pop14_`x'_nat - `x'_pop14) //leave-out version
		}
	gen iv_ven05_`x'_ret0 = censo05_ven_born_`x' * ven_5yr_sh_`x'_nat_ret0
	gen iv_ven93_`x'_ret0 = censo93_ven_born_`x' * ven_5yr_sh_`x'_nat_ret0
	gen iv_dist_`x'_ret0  = (1/min_dist_km) * ven_5yr_sh_`x'_nat_ret0
	gen iv_ven05_`x'_ret0_1yr = censo05_ven_born_`x' * ven_1yr_sh_`x'_nat_ret0
	gen iv_ven93_`x'_ret0_1yr = censo93_ven_born_`x' * ven_1yr_sh_`x'_nat_ret0
	gen iv_dist_`x'_ret0_1yr  = (1/min_dist_km) * ven_1yr_sh_`x'_nat_ret0
	}

* Repeated using 2018 census for just 2018 (same in all years) (as share of censo18 pop)
foreach x in dpto area {
	preserve
	use "$mydir/SALE/data/my_import/censo18_for_born_`x'.dta", clear
	rename for_5yr for_5yr_`x'_censo18
	rename for_5yr_noncol for_5yr_`x'_censo18_ret0
	rename pop pop_`x'_censo18
	keep `x' *censo18*
	tempfile censo18_`x'
	save `censo18_`x''
	restore
	merge m:1 `x' using `censo18_`x''
	assert _merge==3 if dpto!=25
	drop _merge
	bysort year: egen pop_`x'_censo18_nat = sum(pop_`x'_censo18)
	foreach r in "" "_ret0" {
		gen for_5yr_sh_`x'_censo18`r' = 100*(for_5yr_`x'_censo18`r'/pop_`x'_censo18)
		bysort year: egen for_5yr_nat_`x'_censo18`r' = sum(for_5yr_`x'_censo18`r')
		gen for_5yr_sh_nat_`x'_censo18`r' = 100*(for_5yr_nat_`x'_censo18`r' - for_5yr_`x'_censo18`r')/(pop_`x'_censo18_nat - pop_`x'_censo18)
		gen iv_ven05_`x'_censo18`r' = censo05_ven_born_`x' * for_5yr_sh_nat_`x'_censo18`r'
		gen iv_ven93_`x'_censo18`r' = censo93_ven_born_`x' * for_5yr_sh_nat_`x'_censo18`r'
		gen iv_dist_`x'_censo18`r' = (1/min_dist_km) * for_5yr_sh_nat_`x'_censo18`r'
		}
	}

foreach x in dpto area {
	* Repeated using for_5yr in GEIH just 2018 - share of 2018 population
	bysort year: egen pop_`x'_nat = sum(`x'_pop)
	foreach r in "" "_ret0" {
		gen for_5yr_sh_`x'_geih18`r' = 100*(`x'_for_5yr`r'/`x'_pop)
		bysort year: egen for_5yr_nat_`x'_geih18`r' = sum(`x'_for_5yr`r')
		gen f5_sh_nat_`x'_geih18`r' = 100*(for_5yr_nat_`x'_geih18`r' - `x'_for_5yr`r')/(pop_`x'_nat - `x'_pop)
		gen iv_ven05_`x'_geih18`r' = censo05_ven_born_`x' * f5_sh_nat_`x'_geih18`r'
		gen iv_ven93_`x'_geih18`r' = censo93_ven_born_`x' * f5_sh_nat_`x'_geih18`r'
		gen iv_dist_`x'_geih18`r' = (1/min_dist_km) * f5_sh_nat_`x'_geih18`r'
		}
	* Repeated using for_5yr in GEIH just 2019 - share of 2019 population
	foreach r in "" "_ret0" {
		gen for_5yr_sh_`x'_geih19`r' = 100*(`x'_for_5yr`r'/`x'_pop)
		bysort year: egen for_5yr_nat_`x'_geih19`r' = sum(`x'_for_5yr`r')
		gen f5_sh_nat_`x'_geih19`r' = 100*(for_5yr_nat_`x'_geih19`r' - `x'_for_5yr`r')/(pop_`x'_nat - `x'_pop)
		gen iv_ven05_`x'_geih19`r' = censo05_ven_born_`x' * f5_sh_nat_`x'_geih19`r'
		gen iv_ven93_`x'_geih19`r' = censo93_ven_born_`x' * f5_sh_nat_`x'_geih19`r'
		gen iv_dist_`x'_geih19`r' = (1/min_dist_km) * f5_sh_nat_`x'_geih19`r'
		}

	foreach var of varlist *geih18* {
		gen temp = `var' if year==2018
		drop `var'
		bysort `x': egen `var' = max(temp)
		drop temp
		}
	foreach var of varlist *geih19* {
		gen temp = `var' if year==2019
		drop `var'
		bysort `x': egen `var' = max(temp)
		drop temp
		}
	}

* Save
order dpto area year
save "$mydir/data/geih_dpto_area_collapse.dta", replace
