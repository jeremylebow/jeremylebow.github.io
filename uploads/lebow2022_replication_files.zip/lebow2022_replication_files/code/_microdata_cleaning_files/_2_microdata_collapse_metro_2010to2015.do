
* INSERT DIRECTORY:
macro define mydir ""

use "$mydir/data/geih_labor_microdata.dta", replace
keep if age>=15 & age<=64 & metro!=.
keep if year<=2015

macro define labor_collapse "ln_wage ln_hrs lfp unemp formw infmw ownacc employer occup_q_1 occup_q_2 occup_q_3 occup_q_4 occup_q_5"
	
* -------------------------
* Collapse overall
* -------------------------
preserve
collapse (count) pop pop_work pop_lfp (mean) $labor_collapse, by(metro year)
tempfil metro_overall
save `metro_overall'
restore

* --------------------------------------------------
* Collapse by education
* --------------------------------------------------
preserve
keep if educ_group!=.
collapse (count) pop_work (mean) $labor_collapse, by(metro year educ_group)
reshape wide pop_work $labor_collapse, i(metro year) j(educ_group)
foreach var in pop_work $labor_collapse {
	rename `var'1 `var'_e1
	rename `var'2 `var'_e2
	rename `var'3 `var'_e3
}
tempfil metro_educ
save `metro_educ'
restore

* -------------------------
* Merge together
* -------------------------
use `metro_overall', clear
merge 1:1 metro year using `metro_educ'
assert _merge==3
drop _merge

* -------------------------
* Save
* -------------------------

save "$mydir/data/geih_metro_collapse_2010to2015.dta", replace
