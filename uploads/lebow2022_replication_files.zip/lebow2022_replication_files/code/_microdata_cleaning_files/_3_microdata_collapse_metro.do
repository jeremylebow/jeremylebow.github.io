
* INSERT DIRECTORY:
macro define mydir ""

clear all
set maxvar 50000

* ------------------------------------------------------------------------
* ------------------------------------------------------------------------
* Collapse variables at the metro level (commuting-zone defined metro areas)
* ------------------------------------------------------------------------
* ------------------------------------------------------------------------

* ------------------------------------------------------------------------
* Labor market outcomes
* ------------------------------------------------------------------------

macro define labor_collapse1 "ln_wage_res ln_hrs_res lfp_res unemp_res ln_wage ln_hrs lfp unemp formw infmw ownacc employer occup_q_1 occup_q_2 occup_q_3 occup_q_4 occup_q_5 overskilled"
macro define labor_collapse2 "ln_wage_res ln_hrs_res ln_wage ln_hrs"
macro define labor_collapse3 "ln_wage_res ln_hrs_res lfp_res unemp_res formw infmw ownacc employer occup_q_1 occup_q_2 occup_q_3 occup_q_4 occup_q_5 overskilled"

use "$mydir/data/geih_labor_microdata_clean.dta", replace
keep if age>=15 & age<=64 & for_5yr==0 & metro!=.
keep if year>=2014

* Overall
preserve
collapse (count) pop pop_work pop_lfp (mean) $labor_collapse1, by(metro year)
tempfile metro_overall
save `metro_overall', replace
restore

* By gender
preserve
collapse (count) pop pop_work pop_lfp (mean) $labor_collapse1, by(metro year male)
macro define reshape ""
foreach var in pop pop_work pop_lfp $labor_collapse1 {
	rename `var' `var'_m
	macro define reshape "$reshape `var'_m"
	}	
reshape wide $reshape, i(metro year) j(male)
tempfile metro_sex
save `metro_sex', replace
restore

* By age
preserve
keep if age_group!=.
collapse (count) pop pop_work pop_lfp (mean) $labor_collapse1, by(metro year age_group)
macro define reshape ""
foreach var in pop pop_work pop_lfp $labor_collapse1 {
	rename `var' `var'_a
	macro define reshape "$reshape `var'_a"
	}	
reshape wide $reshape, i(metro year) j(age_group)
tempfile metro_age
save `metro_age', replace
restore

* By education
preserve
drop if educ_group==.
collapse (count) pop pop_work pop_lfp (mean) $labor_collapse1, by(metro year educ_group)
macro define reshape ""
foreach var in pop pop_work pop_lfp $labor_collapse1 {
	rename `var' `var'_e
	macro define reshape "$reshape `var'_e"
	}	
reshape wide $reshape, i(metro year) j(educ_group)
tempfile metro_educ
save `metro_educ, replace
restore

* By sector
preserve
drop if sector_group==.
collapse (count) pop_work (mean) $labor_collapse2, by(metro year sector_group)
reshape wide pop_work $labor_collapse2, i(metro year) j(sector_group)
foreach var in pop_work $labor_collapse2 {
	rename `var'1 `var'_s1 //ForMW
	rename `var'2 `var'_s2 //InfMW
	rename `var'3 `var'_s3 //OwnAcc
	rename `var'4 `var'_s4 //Employer
	}	
tempfile metro_sector
save `metro_sector', replace
restore

* By occupation
preserve
drop if occup_decile==.
collapse (count) pop_work (mean) $labor_collapse2, by(metro year occup_decile)
reshape wide pop_work $labor_collapse2, i(metro year) j(occup_decile)
foreach var in pop_work $labor_collapse2 {
	rename `var'1 `var'_d1
	rename `var'2 `var'_d2
	rename `var'3 `var'_d3
	rename `var'4 `var'_d4
	rename `var'5 `var'_d5
	rename `var'6 `var'_d6
	rename `var'7 `var'_d7
	rename `var'8 `var'_d8
	rename `var'9 `var'_d9
	rename `var'10 `var'_d10
	}	
tempfile metro_occup
save `metro_occup', replace
restore

* ------------------------------------------------------------------------
* Labor market outcomes - assigned to lagged metro area
* ------------------------------------------------------------------------

use "$mydir/data/geih_labor_microdata_clean.dta", replace
keep if age>=15 & age<=64 & for_5yr==0
replace metro = intmig_5yr_metro if intmig_5yr==1 //assigned to metro area 5 years ago
keep if metro!=.
keep if year>=2014

* Overall
preserve
collapse (count) pop pop_work pop_lfp (mean) $labor_collapse3, by(metro year)
foreach var in pop pop_work pop_lfp $labor_collapse3 {
	rename `var' `var'_pastmetro
	}
tempfile pastmetro_overall
save `pastmetro_overall', replace
restore

* By education
preserve
drop if educ_group==.
collapse (count) pop pop_work pop_lfp (mean) $labor_collapse3, by(metro year educ_group)
macro define reshape ""
foreach var in pop pop_work pop_lfp $labor_collapse3 {
	rename `var' `var'_pastmetro_e
	macro define reshape "$reshape `var'_pastmetro_e"
	}	
reshape wide $reshape, i(metro year) j(educ_group)
tempfile pastmetro_educ
save `pastmetro_educ', replace
restore

* ------------------------------------------------------------------------
* Migrant share collapse
* ------------------------------------------------------------------------

use "$mydir/data/geih_labor_microdata_clean.dta", replace
keep if age>=15 & age<=64 & metro!=.
keep if year>=2014

* Migrant share (5yr)
preserve
replace ven_5yr = . if ven_5yr==0
collapse (count) ven_5yr, by(metro year)
tempfile metro_mig_5yr
save `metro_mig_5yr', replace
restore

* Migrant share (1yr)
preserve
replace ven_1yr = . if ven_1yr==0
collapse (count) ven_1yr, by(metro year)
tempfile metro_mig_1yr
save `metro_mig_1yr', replace
restore

* Total baseline population
preserve
keep if year==2014
rename pop baselinepop
collapse (count) baselinepop, bymetro year)
tempfile metro_baselinepop
save `metro_baselinepop', replace
restore

* ------------------------------------------------------------------------
* Internal migration outcomes
* ------------------------------------------------------------------------

use "$mydir/data/geih_labor_microdata_clean.dta", replace
keep if age>=15 & age<=64 & for_5yr==0
keep if year>=2014

* 5-Yr Out-Migration - Assign to metro 5 years ago
preserve
keep if year==2014 | year==2019
gen mig_5yr_out = 1 if metro!=intmig_5yr_metro
replace metro = intmig_5yr_metro
tempfile mig_5yr_out
save `mig_5yr_out', replace
gen pop_5yr = 1
tempfile pop_5yr
save `pop_5yr', replace
restore

* 5-Yr In-Migration - Assign to metro today
preserve
keep if year==2014 | year==2019
gen mig_5yr_in = 1 if metro!=intmig_5yr_metro
tempfile mig_5yr_in
save `mig_5yr_in', replace
restore

* Collapse by group
foreach x in "mig_5yr_out" "mig_5yr_in" "pop_5yr" {

	* Overall means
	use ``x'', replace
	collapse (sum) `x', by(metro year)
	tempfile `x'
	save ``x'', replace

	* By sex
	use ``x'', replace
	collapse (sum) `x', by(metro year male)
	reshape wide `x', i(metro year) j(male)
	rename `x'0 `x'_m0
	rename `x'1 `x'_m1
	tempfile `x'_sex
	save ``x'_sex', replace

	* By age
	use ``x'', replace
	collapse (sum) `x', by(metro year age_group)
	reshape wide `x', i(metro year) j(age_group)
	rename `x'1 `x'_a1
	rename `x'2 `x'_a2
	rename `x'3 `x'_a3
	rename `x'4 `x'_a4
	rename `x'5 `x'_a5
	tempfile `x'_age
	save ``x'_age', replace

	* By educ
	use ``x'', replace
	drop if educ_group==.
	collapse (sum) `x', by(metro year educ_group)
	reshape wide `x', i(metro year) j(educ_group)
	rename `x'1 `x'_e1
	rename `x'2 `x'_e2
	rename `x'3 `x'_e3
	tempfile `x'_educ
	save ``x'_educ', replace

	}

* Merge and calculate interal migration shares
use `mig_5yr_out', clear
merge 1:1 metro year using `mig_5yr_in', nogen
merge 1:1 metro year using `pop_5yr', nogen
foreach x in "mig_5yr_out" "mig_5yr_in" "pop_5yr" {
	merge 1:1 metro year using ``x''_sex, nogen
	merge 1:1 metro year using ``x''_age, nogen
	merge 1:1 metro year using ``x''_educ, nogen
}
foreach g in "" "_m0" "_m1" "_e1" "_e2" "_e3" "_a1" "_a2" "_a3" "_a4" "_a5" {
	gen mig_5yr_in_sh`g'  = 100*(mig_5yr_in`g'/pop_5yr`g')
	gen mig_5yr_out_sh`g' = 100*(mig_5yr_out`g'/pop_5yr`g')
	}
keep metro year mig_5yr_in_sh* mig_5yr_out_sh*
tempfile metro_intmig
save `metro_intmig', replace
	
* ------------------------------------------------------------------------
* Merge together
* ------------------------------------------------------------------------

clear all
use `metro_overall', clear
merge 1:1 metro year using `metro_sex'
assert _merge==3
drop _merge
merge 1:1 metro year using `metro_age'
assert _merge==3
drop _merge
merge 1:1 metro year using `metro_educ'
assert _merge==3
drop _merge
merge 1:1 metro year using `metro_sector'
assert _merge==3
drop _merge
merge 1:1 metro year using `metro_occup'
assert _merge==3
drop _merge
merge 1:1 metro year using `pastmetro_overall'
assert _merge!=1
drop if _merge==2
drop _merge
merge 1:1 metro year using `pastmetro_educ'
assert _merge!=1
drop if _merge==2
drop _merge
merge 1:1 metro year using `metro_mig_5yr'
assert _merge==3
drop _merge
merge 1:1 metro year using `metro_mig_1yr'
assert _merge==3
drop _merge
merge m:1 metro using `metro_baselinepop'
assert _merge==3
drop _merge
merge m:1 metro using `metro_intmig'
assert _merge!=1 if year==2014 | year==2019
drop if _merge==2 //not in GEIH
drop _merge

* --------------------------------------------------------
* Generate migrant share and shift-share instrument
* --------------------------------------------------------

* Migrant share
gen ven_5yr_sh = 100*(ven_5yr/baselinepop)

* Leave-one out national "shift"
bysort year: egen ven_5yr_nat = sum(ven_5yr)
bysort year: egen baselinepop_nat = sum(baselinepop)
gen ven_5yr_sh_nat = 100*(ven_5yr_nat - ven_5yr)/(baselinepop_nat - baselinepop)

* Merge metro "share" from complete 2005 census and 10% 1993 census
merge m:1 metro using "$mydir/data/censo05_collapse.dta", keepusing(censo05_ven_born)
assert _merge!=1
drop if _merge==2 //some not in GEIH
drop _merge
merge m:1 metro using "$mydir/data/censo93_collapse.dta", keepusing(censo93_ven_born)
assert _merge!=1
drop if _merge==2 //some not in GEIH
drop _merge

* Merge another option for "share" - driving distance to closest Venezuelan border crossings
merge m:1 metro using "$mydir/data/traveldist_metro.dta", keepusing(dist_km_border_crossings)
assert _merge==3
drop _merge

* Generate instruments
gen iv_ven05 = censo05_ven_born * ven_5yr_sh_nat
gen iv_ven93 = censo93_ven_born * ven_5yr_sh_nat
gen iv_dist = (1/dist_km_border_crossings)*ven_5yr_sh_nat


* Repeated to exclude return migrants, 5-year migrants, and using 2018 census to measure the migrant share
* ----------------------------------------------------------------------------------------------------------
* 1-year migration
gen ven_1yr_sh = 100*(ven_1yr/baselinepop)
bysort year: egen ven_1yr_nat = sum(ven_1yr)
gen ven_1yr_sh_nat = 100*(ven_1yr_nat - ven_1yr)/(baselinepop_nat - baselinepop)
gen iv_ven05_1yr = censo05_ven_born * ven_1yr_sh_nat
gen iv_ven93_1yr = censo93_ven_born_metro * ven_1yr_sh_nat
gen iv_dist_1yr = (1/dist_km_border_crossings)*ven_1yr_sh_nat

* Excluding return migrants
gen ven_5yr_sh_ret0 = 100*(ven_5yr_ret0/baselinepop)
bysort year: egen ven_5yr_nat_ret0 = sum(ven_5yr_ret0)
gen ven_5yr_sh_nat_ret0 = 100*(ven_5yr_nat_ret0 - ven_5yr_ret0)/(baselinepop_nat - baselinepop)
gen iv_ven05_ret0 = censo05_ven_born * ven_5yr_sh_nat_ret0
gen iv_ven93_ret0 = censo93_ven_born * ven_5yr_sh_nat_ret0
gen iv_dist_ret0 = (1/dist_km_border_crossings) * ven_5yr_sh_nat_ret0
gen ven_1yr_sh_ret0 = 100*(ven_1yr_ret0/baselinepop)
bysort year: egen ven_1yr_nat_ret0 = sum(ven_1yr_ret0)
gen ven_1yr_sh_nat_ret0 = 100*(ven_1yr_nat_ret0 - ven_1yr_ret0)/(baselinepop_nat - baselinepop)
gen iv_ven05_ret0_1yr = censo05_ven_born * ven_1yr_sh_nat_ret0
gen iv_ven93_ret0_1yr = censo93_ven_born_metro * ven_1yr_sh_nat_ret0
gen iv_dist_ret0_1yr = (1/dist_km_border_crossings) * ven_1yr_sh_nat_ret0
drop baselinepop*

* Repeated using 2018 census for just 2018, as share of censo18 pop
merge m:1 metro using "$mydir/data/censo18_collapse.dta", keepusing(for_5yr_censo18 for_5yr_censo18_ret0 pop_censo18)
assert _merge!=1
drop if _merge==2 //not in GEIH
drop _merge
bysort year: egen pop_censo18_nat = sum(pop_censo18)
foreach x in "" "_ret0" {
	gen for_5yr_sh_censo18`x' = 100*(for_5yr_censo18`x'/pop_censo18)
	bysort year: egen for_5yr_nat_censo18`x' = sum(for_5yr_censo18`x')
	gen for_5yr_sh_nat_censo18`x' = 100*(for_5yr_nat_censo18`x' - for_5yr_censo18`x')/(pop_censo18_nat - pop_censo18)
	gen iv_ven05_censo18`x' = censo05_ven_born * for_5yr_sh_nat_censo18`x'
	gen iv_ven93_censo18`x' = censo93_ven_born_metro * for_5yr_sh_nat_censo18`x'
	gen iv_dist_censo18`x' = (1/dist_km_border_crossings) * for_5yr_sh_nat_censo18`x'
	}

* Repeated using for_5yr in GEIH just 2018, as share of 2018 population
bysort year: egen pop_nat = sum(pop)
foreach x in "" "_ret0" {
	gen for_5yr_sh_geih18`x' = 100*(for_5yr`x'/pop)
	bysort year: egen for_5yr_nat_geih18`x' = sum(for_5yr`x')
	gen for_5yr_sh_nat_geih18`x' = 100*(for_5yr_nat_geih18`x' - for_5yr`x')/(pop_nat - pop)
	gen iv_ven05_geih18`x' = censo05_ven_born * for_5yr_sh_nat_geih18`x'
	gen iv_ven93_geih18`x' = censo93_ven_born_metro * for_5yr_sh_nat_geih18`x'
	gen iv_dist_geih18`x' = (1/dist_km_border_crossings) * for_5yr_sh_nat_geih18`x'
	}

* Repeated using for_5yr in GEIH just 2019, as share of 2019 population
foreach x in "" "_ret0" {
	gen for_5yr_sh_geih19`x' = 100*(for_5yr`x'/pop)
	bysort year: egen for_5yr_nat_geih19`x' = sum(for_5yr`x')
	gen for_5yr_sh_nat_geih19`x' = 100*(for_5yr_nat_geih19`x' - for_5yr`x')/(pop_nat - pop)
	gen iv_ven05_geih19`x' = censo05_ven_born * for_5yr_sh_nat_geih19`x'
	gen iv_ven93_geih19`x' = censo93_ven_born_metro * for_5yr_sh_nat_geih19`x'
	gen iv_dist_geih19`x' = (1/dist_km_border_crossings) * for_5yr_sh_nat_geih19`x'
	}

* ----------------------------------------------------------------------------------------------------------


* ----------------------------------------
* Additional edits
* ----------------------------------------

* Generate region controls
gen dpto = substr(string(metro,"%05.0f"),1,2)
destring dpto, replace
recode dpto (8 13 20 23 70 47 44 = 1) ///
			(54 68 15 25 50 11 = 2) ///
			(17 66 63 73 41 18 5 = 3) ///
			(27 19 52 76 = 4), gen(region)
label define region 1 "1.Caribe" 2 "2.Oriental+bogota" 3 "3.Central" 4 "4.Pacifica"
label val region region

* Merge trade controls
merge m:1 dpto year using "$mydir/data/ven_trade.dta", keepusing(imp_ven exp_ven)

* Merge regional characteristics
merge m:1 dpto using "$mydir/data/db17.dta", keepusing(db17_business db17_construction db17_property db17_taxes) //World Bank 2017 Doing Business at dpto level
assert _merge==3
drop _merge
merge m:1 dpto using "$mydir/data/pib_pc_dpto.dta", keepusing(pib_pc_2014) //2014 dpto per-capita GDP (DANE)
assert _merge==3
drop _merge

* Region linear trends
gen r_1Xyear = (region==1)*(year-2014)
gen r_2Xyear = (region==2)*(year-2014)
gen r_3Xyear = (region==3)*(year-2014)
gen r_4Xyear = (region==4)*(year-2014)

* Inverse border distance
gen yearXinvdist = (year-2014)*(1/dist_km_border_crossings)

* Pop14XYear
foreach y in 14 15 16 17 18 19 {
	gen year`y'Xpop14 = (year==2000+`y')*pop14
	}

*2013 and 2015 values for trend controls, by outcome and education group
preserve
use "$mydir\data\geih_metro_collapse_2010to2015.dta", clear
foreach e in "" "_e1" "_e2" "_e3" {
	foreach var in ln_wage ln_hrs unemp lfp occup_q_1 occup_q_2 occup_q_3 occup_q_4 occup_q_5 formw infmw ownacc employer {
		gen temp = `var'`e' if year==2013
		bysort metro: egen `var'2013`e' = max(temp)
		drop temp
		gen temp = `var'`e' if year==2015
		bysort metro: egen `var'2015`e' = max(temp)
		drop temp
		gen `var'_13_15`e' =  `var'2015`e' - `var'2013`e'
		}
	}
keep metro *13_15*
duplicates drop
tempfile var2013_2015
save `var2013_2015'
restore
merge m:1 metro using `var2013_2015' //ln_wage14 and ln_wage2014 should be the same
assert _merge==3
drop _merge
foreach e in "" "_e1" "_e2" "_e3" {
	foreach var in ln_wage ln_hrs unemp lfp occup_q_1 occup_q_2 occup_q_3 occup_q_4 occup_q_5 formw infmw ownacc employer {
		gen yearX`var'_13_15`e'   = (year-2013)*`var'_13_15`e'
		}
	}

* ----------------------------------------
* Baseline (2014) measures used in analysis
* ----------------------------------------

foreach var in ln_wage ln_hrs lfp unemp ownacc formal {
	gen temp = `var'`e' if year==2014
	bysort metro: egen `var'14 = max(temp)
	drop temp
	}
	
foreach var in pop pop_work pop_lfp {
	foreach g in "" "_e1" "_e2" "_e3" {
		gen temp = `var'`g' if year==2014
		bysort metro: egen `var'14`g' = max(temp)
		drop temp
		}
	}

* Restrict sample by 2014 native population
keep if pop14>300

* Save
save "$mydir/data/geih_metro_collapse.dta", replace
