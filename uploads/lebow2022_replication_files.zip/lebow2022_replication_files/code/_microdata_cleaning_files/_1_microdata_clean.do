
* INSERT DIRECTORY:
macro define mydir ""

use "$mydir/data/geih_labor_microdata.dta", replace

* -------------------------
* Add metro and area 
* -------------------------
merge m:1 mpio using "$mydir/data/mpio_metro_crosswalk.dta", keepusing(metro area)
drop if _merge==2 //drop mpios not in GEIH
drop _merge
gen dpto = substr(string(mpio,"%05.0f"),1,2)

* -------------------------
* Sex, age, education
* -------------------------

rename p6020 sex
gen byte male = (sex==1)

rename p6040 age
gen byte age_group = 1 if age>=15 & age<=24
replace  age_group = 2 if age>=25 & age<=34
replace  age_group = 3 if age>=35 & age<=44
replace  age_group = 4 if age>=45 & age<=54
replace  age_group = 5 if age>=55 & age<=64
label define age_group 1 "1.15-24" ///
					   2 "2.25-34" ///
					   3 "3.35-44" ///
					   4 "4.45-54" ///
					   5 "5.55-64"
label val age_group age_group

rename p6170 educ_still
rename p6210 educ_lvl
rename esc   educ_yrs
rename p6220 educ_deg
gen     educ_group = 1 if educ_yrs<=9 | (educ_lvl==5 & educ_deg==1) //no media
replace educ_group = 2 if educ_deg==2 //completed media
replace educ_group = 3 if educ_lvl==6 | (educ_deg>=3 & educ_deg<=5) //any post-sec
label define educ_group 1 "1.Not Completed Secondary" ///
						2 "2.Completed Secondary" ///
						3 "3.Post-Secondary"
label val educ_group educ_group

* -------------------------
* Migrant status
* -------------------------

* Born in Venezuela or other country
gen byte for_born = p756==3
gen byte ven_born = p756==3 & p756s3==3

* In Venezuela or other country 5 and 1 yrs ago
* (restricted to born before 5 and 1 yrs ago)
gen byte for_5yr = p755==4 			   if p755!=1
gen byte ven_5yr = p755==4 & p755s3==3 if p755!=1
gen byte for_1yr = p753==4 			   if p753!=1
gen byte ven_1yr = p753==4 & p753s3==3 if p753!=1

* Internal migrants
gen byte intmig_5yr = p755==3 if p755!=1 & p755!=4 //in another mpio (excluding other country)
gen byte intmig_1yr = p753==3 if p753!=1 & p753!=4
rename p755s2 intmig_5yr_mpio
rename p753s2 intmig_1yr_mpio
replace intmig_5yr_mpio = mpio if intmig_5yr!=1
replace intmig_1yr_mpio = mpio if intmig_1yr!=1

* Add past metro area
rename mpio mpio1
rename metro metro1
rename intmig_5yr_mpio mpio
merge m:1 mpio using "$mydir/data/mpio_metro_crosswalk.dta", keepusing(metro)
drop if _merge==2
drop _merge
rename metro intmig_5yr_metro
rename mpio intmig_5yr_mpio
rename intmig_1yr_mpio mpio
merge m:1 mpio using "$mydir/data/mpio_metro_crosswalk.dta", keepusing(metro)
drop if _merge==2
drop _merge
rename metro intmig_1yr_metro
rename mpio intmig_1yr_mpio
rename metro1 metro
rename mpio1 mpio

* -------------------------
* Work status and sector
* -------------------------

* Work Status
gen byte work_status = 1 if p6240==1 | p6250==1 | p6260==1 | p6270==1 //any paid or unpaid work
replace  work_status = 2 if p6240!=1 & p6250!=1 & p6260!=1 & p6270!=1 & p6351==1 //able to work past week
replace  work_status = 3 if p6240!=1 & p6250!=1 & p6260!=1 & p6270!=1 & p6351!=1 //not able to work past week
replace  work_status = 4 if work_status==1 & (p6430==6 | p6430==7) //not able to work past week
label define work_status 1 "1.Ocupado" 2 "2.Desocupado" 3 "3.Inactivo" 4 "4.No pagado"
label val work_status work_status

* Work Sector
recode p6430 (1 3 8 = 1) (2 = 2) (4 = 3) (5 = 4) (6 7 = 5) (9 = 6), gen(work_sector)
label define work_sector 1 "1.Private" ///
						 2 "2.Public" ///
						 3 "3.Own-Account" ///
						 4 "4.Employer" ///
						 5 "5.Unpaid" ///
						 6 "6.Other"
label val work_sector work_sector
rename p6430 work_sector_orig

* Formality
rename p6920 pension
label define pension 1 "1.Yes" 2 "2.No" 3 "3.Already Retired" 9 "9.DK"
label val pension pension
rename p6915 health
gen byte formal = (health==1 & pension==1) if pension<=2 //contributes to ESP and has pension (.3% missing pension info)

* Final sector groups (excludes public, unpaid, other)
gen byte sector_group = 1 if work_sector==1 & formal==1
replace  sector_group = 2 if work_sector==1 & formal==0
replace  sector_group = 3 if work_sector==3
replace  sector_group = 4 if work_sector==4
label define sector_group 1 "1.Formal MW"   ///
						  2 "2.Informal MW" ///
						  3 "3.OwnAcc"      ///
						  4 "4.Employer"
label val sector_group sector_group

* Underemployment - would like to change job, and listed over-skilled as a reason
gen byte overskilled = 100*(p7130==1 & p7140s1==1) //if p7130!=. - making unconditional on working or wanting to change job
label var overskilled "Would you like to change your job:To improve use of skills or training?"
replace overskilled = 0 if work_status!=1 //.5% were positive somehow

* Occupation skill groups
rename oficio occup
merge m:1 occup using "$mydir/data/geih_occup_groups.dta", keepusing (occup_quintile occup_decile)
assert _merge==3 if occup!=. & occup!=0
drop _merge

* -------------------------
* Hours and earnings
* -------------------------

* Monthly income (not including gov subsidios or workers compensation)
gen income = p6500
replace income = income + p6510s1 if p6510==1 & p6510s2==2 & p6510s1!=. //add overtime if not already included
replace income = income + p6590s1 if p6590==1 & p6590s1!=. //add food value
replace income = income + p6600s1 if p6600==1 & p6600s1!=. //add housing value
replace income = income + p6610s1 if p6610==1 & p6610s1!=. //add transport value
replace income = income + p6620s1 if p6620==1 & p6620s1!=. //add other in-kind value
replace income = income + p6580s1 if p6580==1 & p6580s2==2 & p6580s1!=. //monthly bonus if not included
replace income = income + p6630s1a1/12 if p6630s1==1 & p6630s1a1!=. //past-yr one-time bonus
replace income = income + p6630s2a1/12 if p6630s2==1 & p6630s2a1!=. //past-yr christmas bonus
replace income = income + p6630s3a1/12 if p6630s3==1 & p6630s3a1!=. //past-yr vacation bonus
replace income = income + p6630s4a1/12 if p6630s4==1 & p6630s4a1!=. //past-yr annual bonus
replace income = p6750 if p6750!=. //self-emp income

* National-level CPI adjustments - Using IFS from IMF, 2010 base year, converting to 2018 base
foreach var of varlist income {
	replace `var' = `var'*(136.15/100) 	  if year==2010
	replace `var' = `var'*(136.15/103.42) if year==2011
	replace `var' = `var'*(136.15/106.69) if year==2012
	replace `var' = `var'*(136.15/108.85) if year==2013
	replace `var' = `var'*(136.15/112.00) if year==2014
	replace `var' = `var'*(136.15/117.59) if year==2015
	replace `var' = `var'*(136.15/112.00) if year==2014
	replace `var' = `var'*(136.15/117.59) if year==2015
	replace `var' = `var'*(136.15/126.43) if year==2016
	replace `var' = `var'*(136.15/131.88) if year==2017
	replace `var' = `var'*(136.15/136.15) if year==2018
	replace `var' = `var'*(136.15/140.95) if year==2019
	}
	
* Typical Hrs/wk
gen hrs_wk = p6800

* Hrly income
gen wage = income/(hrs_wk*4.2)

* -------------------------
* Keep analysis variables
* -------------------------

macro define finalvar "metro area dpto year fex_c male age* educ* ven_* for_* intmig_* working formal sector_group hrs_wk wage occup* overskilled"
keep $finalvar
order $finalvar

* -------------------------
* Labor outcome edits
* -------------------------

gen ln_hrs  = 100*ln(hrs_wk)
gen ln_wage = 100*ln(wage)
gen byte lfp = 100*(work_status==1 | work_status==2) if work_status!=.
gen byte unemp = 100*(work_status==2) if work_status<=2

gen byte formw = 100*(sector_group==1)
gen byte infmw = 100*(sector_group==2)
gen byte ownacc = 100*(sector_group==3)
gen byte employer = 100*(sector_group==4)

foreach x of numlist 1/5 {
	gen byte occup_q_`x' = 100*(occup_quintile==`x')
	}

foreach x of numlist 1/10 {
	gen byte occup_d_`x' = 100*(occup_decile==`x')
	}

* Residualize key labor outcomes
foreach var of varlist ln_wage ln_hrs lfp unemp {
	reg `var' male i.age_group i.educ_group i.metro i.year, robust
	predict `var'_res, resid
	}

* Windsorize .5% tails, within year
foreach var of varlist ln_wage ln_wage_res {
	foreach y of numlist 2010 2011 2012 2013 2014 2015 2016 2017 2018 2019 {
		qui sum `var' if year==`y', d
		qui sum `var' if year==`y' & `var'>`r(p99)', d
		local top = `r(p50)'
		qui sum `var' if year==`y', d
		qui sum `var' if year==`y' & `var'<`r(p1)', d
		local bot = `r(p50)'
		replace `var' = `top' if year==`y' & `var'>`top' & `var'!=.
		replace `var' = `bot' if year==`y' & `var'<`bot'
		}
	}
	
* Adjust national weights for yearly collapse
replace fex_c = fex_c/12

drop if metro==5250 //only in 2019

gen byte pop = 1
gen byte pop_work = 1 if work_status==1
gen byte pop_lfp = 1 if work_status==1 | work_status==2

* Save
save "$mydir/data/geih_labor_microdata_clean.dta", replace
