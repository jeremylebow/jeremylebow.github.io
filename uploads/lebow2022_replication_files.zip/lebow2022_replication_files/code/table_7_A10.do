
use "$mydir/data/geih_metro_collapse.dta", clear

gen inf14 = 100-formal14
replace ln_wage14 = ln_wage14/100
replace pib_pc_2014 = (pib_pc_2014*0.0005)/1000 //to 2014 $1,000 USD
foreach var of varlist ln_wage14 unemp14 inf14 ownacc14 db17* pib_pc_2014 {
	assert `var'!=.
	qui sum `var' if year==2014
	replace `var' = (`var'-`r(mean)')/`r(sd)'
	gen venX`var' = ven_5yr_sh*`var'
	gen ivX`var' = iv_ven05*`var'
	}

* ------------------------------------------------------
* --------------------- TABLE 7 ------------------------
* ------------------------------------------------------

local n = 0
foreach var in "ln_wage14" "unemp14" "inf14" "ownacc14" "db17_business" "db17_construction" "db17_property" "db17_taxes" "pib_pc_2014" {
	qui ivreg2 ln_wage_res (ven_5yr_sh venX`var' = iv_ven05 ivX`var') i.metro i.year [aw=pop_work], cluster(metro) partial(i.metro i.year)
	local n = `n'+1
		global N`n': di %6.0gc e(N)
		global F`n': di %6.2fc e(widstat)
		global b`n': di %6.2fc _b[ven_5yr_sh]
		global bX`n': di %6.2fc _b[venX`var']
		global se`n': di %6.2fc _se[ven_5yr_sh]			
		global seX`n': di %6.2fc _se[venX`var']
		qui test ven_5yr_sh = 0
		global p`n': di %6.3fc r(p)
		global st`n'=cond(${p`n'}<.01,"***",cond(${p`n'}<.05,"**",cond(${p`n'}<.1,"*","")))
		qui test venX`var' = 0
		global pX`n': di %6.3fc r(p)
		global stX`n'=cond(${pX`n'}<.01,"***",cond(${pX`n'}<.05,"**",cond(${pX`n'}<.1,"*","")))
	
		}

texdoc init "$mydir/output/table7.tex", replace force
tex \begin{threeparttable}
tex \setlength\extrarowheight{-5pt}
tex \begin{tabular}{lccccccccc}
tex \toprule \toprule \addlinespace
tex & \multicolumn{9}{c}{\textbf{\underline{Ln(Hrly Wage)}}} \\ \addlinespace
tex & (1) & (2) & (3) & (4) & (5) & (6) & (7) & (8) & (9) \\ \addlinespace
tex Migrant Share     & ${b1}${st1} & ${b2}${st2} & ${b3}${st3} & ${b4}${st4} & ${b5}${st5} & ${b6}${st6} & ${b7}${st7} & ${b8}${st8} & ${b8}${st9} \\
tex  		          & (${se1}) 	& (${se2}) 	  & (${se3}) 	& (${se4}) 	  & (${se5}) 	& (${se6}) 	  & (${se7}) 	& (${se8}) 	  & (${se9}) 	\\ \addlinespace
tex Migrant Share X 2014 Mean Ln(Hrly Wage)  & ${bX1}${stX1} & & & & & & & & \\
tex  		          				   		 & (${seX1}) 	& & & & & & & &  \\ \addlinespace
tex Migrant Share X 2014 Unemployment Rate & & ${bX2}${stX2} & & & & & & &   \\
tex  		          				       & & (${seX2}) 	 & & & & & & &   \\ \addlinespace
tex Migrant Share X 2014 Informal Rate & & & ${bX3}${stX3} & & & & & &    \\
tex  		          				   & & & (${seX3}) 	   & & & & & &    \\ \addlinespace
tex Migrant Share X 2014 Own-Account Rate & & & & ${bX4}${stX4}  & & & & &  \\
tex  		          				      & & & & (${seX4})      & & & & &   \\ \addlinespace
tex Migrant Share X 2017 WB DB (Starting a Business) & & & & & ${bX5}${stX5} & & & & \\
tex  		          				                 & & & & & (${seX5}) 	 & & & & \\ \addlinespace
tex Migrant Share X 2017 WB DB (Construction Permits) & & & & & & ${bX6}${stX6} & & & \\
tex  		          				                  & & & & & & (${seX6})     & & & \\ \addlinespace
tex Migrant Share X 2017 WB DB (Registering Property) & & & & & & & ${bX7}${stX7} & & \\
tex  		          				                  & & & & & & & (${seX7}) 	  & & \\ \addlinespace
tex Migrant Share X 2017 WB DB (Paying Taxes) & & & & & & & & ${bX8}${stX8} & \\
tex  		          				          & & & & & & & & (${seX8}) 	& \\ \addlinespace 
tex Migrant Share X 2014 Per-Capita GDP & & & & & & & & & ${bX9}${stX9} \\
tex  		          				    & & & & & & & & & (${seX9}) 	   \\ \addlinespace \midrule \addlinespace
tex Kleibergen-Paap Wald Stat. & ${F1} & ${F2} & ${F3} & ${F4} & ${F5} & ${F6} & ${F7} & ${F8} & ${F9} \\ \addlinespace
tex N 						   & ${N1} & ${N2} & ${N3} & ${N4} & ${N5} & ${N6} & ${N7} & ${N8} & ${N9} \\
tex \bottomrule \bottomrule
tex \end{tabular}
tex \begin{tablenotes}
tex \small
tex \item Both the endogenous variable and the instrument are interacted with the interaction variable indicated in each row. All interaction variables are centered around 0 and divided by the standard error. 2014 metro-level economic indicates measured using the GEIH. Doing Business measures at the department level were taken from the World Bank 2017 Doing Business report. 2014 per-capita GDP at the department level downloaded from DANE. All models include Year FE and City FE. Observations weighted by city-year population. Cluster-robust standard errors in parentheses. * p$<$0.10, ** p$<$0.05, *** p$<$0.01.
tex \end{tablenotes}
tex \end{threeparttable}
texdoc close

* -------------------------------------------------------------------
* --------------------- TABLE 7 - Robustness ------------------------
* -------------------------------------------------------------------

macro define lbl_m01 "Original"
macro define lbl_m02 "2SLS"
macro define lbl_m03 ""
macro define lbl_m11 "Drop $<$100km"
macro define lbl_m12 "from Border"
macro define lbl_m13 ""
macro define lbl_m21 "Control"
macro define lbl_m22 "Trade with"
macro define lbl_m23 "Venezuela"
macro define lbl_m31 "Year Trend X"
macro define lbl_m32 "Inv Distance"
macro define lbl_m33 "to Border"
macro define lbl_m41 "Year Trend X"
macro define lbl_m42 "Region"
macro define lbl_m43 ""
macro define lbl_m51 "Year Trend X"
macro define lbl_m52 "Pre-trend"
macro define lbl_m53 ""
macro define lbl_m61 "Drop"
macro define lbl_m62 "Bogotá"
macro define lbl_m63 ""
macro define lbl_m71 "Drop Metro"
macro define lbl_m72 "Yrly Sample"
macro define lbl_m73 "$<$1,000"
macro define lbl_m81 "2014-2019"
macro define lbl_m82 "Difference"
macro define lbl_m83 "Model"
macro define lbl_m91 "Kronmal"
macro define lbl_m92 "Specification"
macro define lbl_m93 ""
macro define lbl_m101 "Assign"
macro define lbl_m102 "Natives to"
macro define lbl_m103 "Past Metro"

foreach m in "m0" "m1" "m2" "m3" "m4" "m5" "m6" "m7" "m8" "m9" "m10" {  
	
	use "$mydir/data/geih_metro_collapse.dta", clear

	if "`m'"=="m10" {
		foreach var of varlist ln_wage_res pop_work {
			replace `var'  = `var'_pastmetro
			}
		}

	if "`m'"=="m9" {	
		replace ven_5yr_sh = ven_5yr/100
		}

	gen inf14 = 100-formal14
	replace ln_wage14 = ln_wage14/100
	replace pib_pc_2014 = (pib_pc_2014*0.0005)/1000 //to 2014 $1,000 USD
	foreach var of varlist ln_wage14 unemp14 inf14 ownacc14 db17* pib_pc_2014 {
		assert `var'!=.
		qui sum `var' if year==2014
		replace `var' = (`var'-`r(mean)')/`r(sd)'
		gen venX`var' = ven_5yr_sh*`var'
		gen ivX`var' = iv_ven05*`var'
		}
		
	if "`m'"=="m8" {
		local add = "14"
		local dif = "_dif"
		local partial = ""
		foreach var of varlist ven_5yr_sh iv_ven05 ln_wage_res {
			gen temp = `var' if year==2014
			bysort metro: egen `var'14 = max(temp)
			drop temp
			gen temp = `var' if year==2019
			bysort metro: egen `var'19 = max(temp)
			drop temp
			gen `var'_dif = `var'19 - `var'14
			}
		foreach var in "ln_wage14" "unemp14" "inf14" "ownacc14" "db17_business" "db17_construction" "db17_property" "db17_taxes" "pib_pc_2014" {
			foreach g in "venX" "ivX" {
				gen temp = `g'`var' if year==2014
				bysort metro: egen `g'`var'14 = max(temp)
				drop temp
				gen temp = `g'`var' if year==2019
				bysort metro: egen `g'`var'19 = max(temp)
				drop temp
				gen `g'`var'_dif = `g'`var'19 - `g'`var'14
				}
			}
		}
	else if "`m'"!="m8" {
		local dif = ""
		local add = ""
		local partial = "partial(i.metro i.year)"
		}

local v=0
foreach var in "ln_wage14" "unemp14" "inf14" "ownacc14" "db17_business" "db17_construction" "db17_property" "db17_taxes" "pib_pc_2014" {
		local v = `v'+1

		macro define m0 "(ven_5yr_sh venX`var' = iv_ven05 ivX`var') i.metro i.year" //Original
		macro define m1 "(ven_5yr_sh venX`var' = iv_ven05 ivX`var') i.metro i.year if dist_km_border_crossings>100" //No within 100km of border
		macro define m2 "(ven_5yr_sh venX`var' = iv_ven05 ivX`var') i.metro i.year imp_ven exp_ven" //Control imports/exports
		macro define m3 "(ven_5yr_sh venX`var' = iv_ven05 ivX`var') i.metro i.year yearXinvdist" //Border distance X Year trend
		macro define m4 "(ven_5yr_sh venX`var' = iv_ven05 ivX`var') i.metro i.year r_*Xyear" //Region X Year trend
		macro define m5 "(ven_5yr_sh venX`var' = iv_ven05 ivX`var') i.metro i.year yearXln_wage_13_15" //Pre-trend trend X Year trend
		macro define m6 "(ven_5yr_sh venX`var' = iv_ven05 ivX`var') i.metro i.year if metro!=11001" //No Bogota
		macro define m7 "(ven_5yr_sh venX`var' = iv_ven05 ivX`var') i.metro i.year if pop14>1000" //Increase SS restriction to min 1,000-year
		macro define m8 "(ven_5yr_sh_dif venX`var'_dif = iv_ven05_dif ivX`var'_dif) if year==2019" //2014-2019 difference model
		macro define m9 "(ven_5yr_sh venX`var' = iv_ven05 ivX`var') year*Xpop14 i.metro i.year" //Kronmal specification (ven_5yr in numbers, control pop)
		macro define m10 "(ven_5yr_sh venX`var' = iv_ven05 ivX`var') i.metro i.year" //Past metro (same as original)

		qui ivreg2 ln_wage_res`dif' ${`m'} [aw=pop_work`add'], cluster(metro) `partial'

			global N_v`v'_`m': di %6.0gc e(N)
			global M_v`v'_`m': di %6.0gc e(N_clust)
			global b_v`v'_`m': di %6.2fc _b[venX`var'`dif']
			global se_v`v'_`m': di %6.2fc _se[venX`var'`dif']	
			global F_v`v'_`m': di %6.2fc e(widstat)
			if `e(widstat)'>16 {
				global F2_v`v'_`m' = "$\dagger$"
				}
			else if `e(widstat)'<=16 {
				global F2_v`v'_`m' = ""
				}
			qui test venX`var'`dif' = 0
			global p_v`v'_`m': di %6.3fc r(p)
			global st_v`v'_`m'=cond(${p_v`v'_`m'}<.01,"***",cond(${p_v`v'_`m'}<.05,"**",cond(${p_v`v'_`m'}<.1,"*","")))
			}
		}
	
texdoc init "$mydir/output/tableA10.tex", replace force
tex \begin{threeparttable}
tex \setlength\extrarowheight{-5pt}
tex \begin{tabular}{lc@{\hskip .3in}c@{\hskip .3in}c@{\hskip .3in}c@{\hskip .3in}c@{\hskip .3in}c@{\hskip .3in}c@{\hskip .3in}c@{\hskip .3in}c@{\hskip .3in}c@{\hskip .3in}c}
tex \toprule \toprule
tex & (1) & (2) & (3) & (4) & (5) & (6) & (7) & (8) & (9) & (10) & (11) \\ \addlinespace
tex  					    & $lbl_m01 & $lbl_m11 & $lbl_m21 & $lbl_m31 & $lbl_m41 & $lbl_m51 & $lbl_m61 & $lbl_m71 & $lbl_m81 & $lbl_m91 & $lbl_m101 \\
tex  						& $lbl_m02 & $lbl_m12 & $lbl_m22 & $lbl_m32 & $lbl_m42 & $lbl_m52 & $lbl_m62 & $lbl_m72 & $lbl_m82 & $lbl_m92 & $lbl_m102 \\
tex Interaction Variable:   & $lbl_m03 & $lbl_m13 & $lbl_m23 & $lbl_m33 & $lbl_m43 & $lbl_m53 & $lbl_m63 & $lbl_m73 & $lbl_m83 & $lbl_m93 & $lbl_m103 \\ \addlinespace \midrule
tex 2014 Mean Ln(Hrly Wage) &${b_v1_m0}${st_v1_m0}${F2_v1_m0}&${b_v1_m1}${st_v1_m1}${F2_v1_m1}&${b_v1_m2}${st_v1_m2}${F2_v1_m2}&${b_v1_m3}${st_v1_m3}${F2_v1_m3}&${b_v1_m4}${st_v1_m4}${F2_v1_m4}&${b_v1_m5}${st_v1_m5}${F2_v1_m5}&${b_v1_m6}${st_v1_m6}${F2_v1_m6}&${b_v1_m7}${st_v1_m7}${F2_v1_m7}&${b_v1_m8}${st_v1_m8}${F2_v1_m8}&${b_v1_m9}${st_v1_m9}${F2_v1_m9}&${b_v1_m10}${st_v1_m10}${F2_v1_m10}\\
tex 		      & (${se_v1_m0})	      & (${se_v1_m1})	   	& (${se_v1_m2})	      & (${se_v1_m3})	    & (${se_v1_m4})	      & (${se_v1_m5})	   	& (${se_v1_m6})	   	  & (${se_v1_m7})  & (${se_v1_m8})  & (${se_v1_m9}) & (${se_v1_m10})	   	\\ \addlinespace
tex 2014 Unemployment Rate &${b_v2_m0}${st_v2_m0}${F2_v2_m0}&${b_v2_m1}${st_v2_m1}${F2_v2_m1}&${b_v2_m2}${st_v2_m2}${F2_v2_m2}&${b_v2_m3}${st_v2_m3}${F2_v2_m3}&${b_v2_m4}${st_v2_m4}${F2_v2_m4}&${b_v2_m5}${st_v2_m5}${F2_v2_m5}&${b_v2_m6}${st_v2_m6}${F2_v2_m6}&${b_v2_m7}${st_v2_m7}${F2_v2_m7}&${b_v2_m8}${st_v2_m8}${F2_v2_m8}&${b_v2_m9}${st_v2_m9}${F2_v2_m9}&${b_v2_m10}${st_v2_m10}${F2_v2_m10}\\
tex 		      & (${se_v2_m0})	      & (${se_v2_m1})	   	& (${se_v2_m2})	      & (${se_v2_m3})	    & (${se_v2_m4})	      & (${se_v2_m5})	   	& (${se_v2_m6})	   	  & (${se_v2_m7})  & (${se_v2_m8})  & (${se_v2_m9}) & (${se_v2_m10})	   	\\ \addlinespace
tex 2014 Informal Rate &${b_v3_m0}${st_v3_m0}${F2_v3_m0}&${b_v3_m1}${st_v3_m1}${F2_v3_m1}&${b_v3_m2}${st_v3_m2}${F2_v3_m2}&${b_v3_m3}${st_v3_m3}${F2_v3_m3}&${b_v3_m4}${st_v3_m4}${F2_v3_m4}&${b_v3_m5}${st_v3_m5}${F2_v3_m5}&${b_v3_m6}${st_v3_m6}${F2_v3_m6}&${b_v3_m7}${st_v3_m7}${F2_v3_m7}&${b_v3_m8}${st_v3_m8}${F2_v3_m8}&${b_v3_m9}${st_v3_m9}${F2_v3_m9}&${b_v3_m10}${st_v3_m10}${F2_v3_m10}\\
tex 		      & (${se_v3_m0})	      & (${se_v3_m1})	   	& (${se_v3_m2})	      & (${se_v3_m3})	    & (${se_v3_m4})	      & (${se_v3_m5})	   	& (${se_v3_m6})	   	  & (${se_v3_m7})  & (${se_v3_m8})  & (${se_v3_m9})	 & (${se_v3_m10})	   	\\ \addlinespace
tex 2014 Own-Account Rate &${b_v4_m0}${st_v4_m0}${F2_v4_m0}&${b_v4_m1}${st_v4_m1}${F2_v4_m1}&${b_v4_m2}${st_v4_m2}${F2_v4_m2}&${b_v4_m3}${st_v4_m3}${F2_v4_m3}&${b_v4_m4}${st_v4_m4}${F2_v4_m4}&${b_v4_m5}${st_v4_m5}${F2_v4_m5}&${b_v4_m6}${st_v4_m6}${F2_v4_m6}&${b_v4_m7}${st_v4_m7}${F2_v4_m7}&${b_v4_m8}${st_v4_m8}${F2_v4_m8}&${b_v4_m9}${st_v4_m9}${F2_v4_m9}&${b_v4_m10}${st_v4_m10}${F2_v4_m10}\\
tex 		      & (${se_v4_m0})	      & (${se_v4_m1})	   	& (${se_v4_m2})	      & (${se_v4_m3})	    & (${se_v4_m4})	      & (${se_v4_m5})	   	& (${se_v4_m6})	   	  & (${se_v4_m7})  & (${se_v4_m8})  & (${se_v4_m9})	  & (${se_v4_m10})	   	\\ \addlinespace
tex WB DB (Starting a Business) &${b_v5_m0}${st_v5_m0}${F2_v5_m0}&${b_v5_m1}${st_v5_m1}${F2_v5_m1}&${b_v5_m2}${st_v5_m2}${F2_v5_m2}&${b_v5_m3}${st_v5_m3}${F2_v5_m3}&${b_v5_m4}${st_v5_m4}${F2_v5_m4}&${b_v5_m5}${st_v5_m5}${F2_v5_m5}&${b_v5_m6}${st_v5_m6}${F2_v5_m6}&${b_v5_m7}${st_v5_m7}${F2_v5_m7}&${b_v5_m8}${st_v5_m8}${F2_v5_m8}&${b_v5_m9}${st_v5_m9}${F2_v5_m9}&${b_v5_m10}${st_v5_m10}${F2_v5_m10}\\
tex 		      & (${se_v5_m0})	      & (${se_v5_m1})	   	& (${se_v5_m2})	      & (${se_v5_m3})	    & (${se_v5_m4})	      & (${se_v5_m5})	   	& (${se_v5_m6})	   	  & (${se_v5_m7})  & (${se_v5_m8})  & (${se_v5_m9})	  & (${se_v5_m10})	   	\\ \addlinespace
tex WB DB (Construction Permits)   &${b_v6_m0}${st_v6_m0}${F2_v6_m0}&${b_v6_m1}${st_v6_m1}${F2_v6_m1}&${b_v6_m2}${st_v6_m2}${F2_v6_m2}&${b_v6_m3}${st_v6_m3}${F2_v6_m3}&${b_v6_m4}${st_v6_m4}${F2_v6_m4}&${b_v6_m5}${st_v6_m5}${F2_v6_m5}&${b_v6_m6}${st_v6_m6}${F2_v6_m6}&${b_v6_m7}${st_v6_m7}${F2_v6_m7}&${b_v6_m8}${st_v6_m8}${F2_v6_m8}&${b_v6_m9}${st_v6_m9}${F2_v6_m9}&${b_v6_m10}${st_v6_m10}${F2_v6_m10}\\
tex 		    	  & (${se_v6_m0})	    & (${se_v6_m1})	   	  & (${se_v6_m2})	    & (${se_v6_m3})	      & (${se_v6_m4})	    & (${se_v6_m5})	   	  & (${se_v6_m6})	    & (${se_v6_m7})	 & (${se_v6_m8})  & (${se_v6_m9})& (${se_v6_m10})  	\\ \addlinespace
tex WB DB (Registering Property) &${b_v7_m0}${st_v7_m0}${F2_v7_m0}&${b_v7_m1}${st_v7_m1}${F2_v7_m1}&${b_v7_m2}${st_v7_m2}${F2_v7_m2}&${b_v7_m3}${st_v7_m3}${F2_v7_m3}&${b_v7_m4}${st_v7_m4}${F2_v7_m4}&${b_v7_m5}${st_v7_m5}${F2_v7_m5}&${b_v7_m6}${st_v7_m6}${F2_v7_m6}&${b_v7_m7}${st_v7_m7}${F2_v7_m7}&${b_v7_m8}${st_v7_m8}${F2_v7_m8}&${b_v7_m9}${st_v7_m9}${F2_v7_m9}&${b_v7_m10}${st_v7_m10}${F2_v7_m10}\\
tex 		    	  & (${se_v7_m0})	    & (${se_v7_m1})	   	  & (${se_v7_m2})	    & (${se_v7_m3})	      & (${se_v7_m4})	    & (${se_v7_m5})	   	  & (${se_v7_m6})	    & (${se_v7_m7})	 & (${se_v7_m8})  & (${se_v7_m9}) & (${se_v7_m10})  	\\ \addlinespace
tex WB DB (Paying Taxes)       &${b_v8_m0}${st_v8_m0}${F2_v8_m0}&${b_v8_m1}${st_v8_m1}${F2_v8_m1}&${b_v8_m2}${st_v8_m2}${F2_v8_m2}&${b_v8_m3}${st_v8_m3}${F2_v8_m3}&${b_v8_m4}${st_v8_m4}${F2_v8_m4}&${b_v8_m5}${st_v8_m5}${F2_v8_m5}&${b_v8_m6}${st_v8_m6}${F2_v8_m6}&${b_v8_m7}${st_v8_m7}${F2_v8_m7}&${b_v8_m8}${st_v8_m8}${F2_v8_m8}&${b_v8_m9}${st_v8_m9}${F2_v8_m9}&${b_v8_m10}${st_v8_m10}${F2_v8_m10}\\
tex 		    	  & (${se_v8_m0})	    & (${se_v8_m1})	   	  & (${se_v8_m2})	    & (${se_v8_m3})	      & (${se_v8_m4})	    & (${se_v8_m5})	   	  & (${se_v8_m6})	    & (${se_v8_m7})	 & (${se_v8_m8}) & (${se_v8_m9}) & (${se_v8_m10})   	\\ \addlinespace
tex 2014 Per-Capita GDP          &${b_v9_m0}${st_v9_m0}${F2_v9_m0}&${b_v9_m1}${st_v9_m1}${F2_v9_m1}&${b_v9_m2}${st_v9_m2}${F2_v9_m2}&${b_v9_m3}${st_v9_m3}${F2_v9_m3}&${b_v9_m4}${st_v9_m4}${F2_v9_m4}&${b_v9_m5}${st_v9_m5}${F2_v9_m5}&${b_v9_m6}${st_v9_m6}${F2_v9_m6}&${b_v9_m7}${st_v9_m7}${F2_v9_m7}&${b_v9_m8}${st_v9_m8}${F2_v9_m8}&${b_v9_m9}${st_v9_m9}${F2_v9_m9}&${b_v9_m10}${st_v9_m10}${F2_v9_m10}\\
tex 		    	  & (${se_v9_m0})	    & (${se_v9_m1})	   	  & (${se_v9_m2})	    & (${se_v9_m3})	      & (${se_v9_m4})	    & (${se_v9_m5})	   	  & (${se_v9_m6})	    & (${se_v9_m7})	 & (${se_v9_m8}	 & (${se_v9_m9})& (${se_v9_m10})  	\\ \addlinespace
tex \midrule \addlinespace
tex N						   & ${N_v1_m0} & ${N_v1_m1} & ${N_v1_m2} & ${N_v1_m3} & ${N_v1_m4} & ${N_v1_m5} & ${N_v1_m6} & ${N_v1_m7} & ${N_v1_m8} & ${N_v1_m9} & ${N_v1_m10} \\
tex \bottomrule \bottomrule
tex \end{tabular}
tex \begin{tablenotes}
tex \small
tex \item Each row presents the interaction coefficient from a separate regression using the indicated interaction variable. $\dagger$ indicates that the Kleibergen-Paap Wald Statistic is greater than 16. See notes to Table \ref{table:reg-interactions}. Cluster-robust standard errors in parentheses. * p$<$0.10, ** p$<$0.05, *** p$<$0.01.
tex \end{tablenotes}
tex \end{threeparttable}
texdoc close

