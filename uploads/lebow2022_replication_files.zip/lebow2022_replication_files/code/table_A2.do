
use "$mydir/data/geih_metro_collapse.dta", clear

keep if year==2019

replace pop14 = pop14*(350/100000)

macro define m1 "pop14"
macro define m2 "pop14 ln_wage14"
macro define m3 "pop14 ln_wage14 ln_hrs14 unemp14"
macro define m4 "pop14 ln_wage14 ln_hrs14 unemp14"
macro define m5 "pop14 ln_wage14 ln_hrs14 unemp14 lfp14"

egen censo05_ven_born_std = std(censo05_ven_born)

foreach m in "m1" "m2" "m3" "m4" "m5" {
	qui reg censo05_ven_born_std ${`m'} [aw=pop], robust
		global N_`m': di %8.0gc e(N)
		global r2_`m': di %6.2gc e(r2)
		if ${r2_`m'}<.0001 {
			global r2_`m' = ".00"
			}
		matrix B = e(b)
		matrix V = e(V)
		gen temp = "`e(cmdline)'"
		split temp
		foreach n of numlist 1/5 {
			global b_`m'_`n': di %6.3fc B[1,`n']
			global se_`m'_`n': di %6.3fc sqrt(V[`n',`n'])
			local n2 = `n' + 2
			cap local test`n' = temp`n2'
			cap qui test "`test`n''" = 0
			global p_`m'_`n': di %6.3fc r(p)
			global st_`m'_`n'=cond(${p_`m'_`n'}<.01,"***",cond(${p_`m'_`n'}<.05,"**",cond(${p_`m'_`n'}<.1,"*","")))
			}
		drop temp*
	}

texdoc init "$mydir/output/tableA2.tex", replace force
tex \begin{threeparttable}
tex \setlength\extrarowheight{-5pt}
tex \begin{tabular}{lccccc}
tex \toprule \toprule
tex & (1) & (2) & (3) & (4) & (5) \\
tex \textbf{2014 Metro Characteristic:} & $ V_{c,2005}$ & $ V_{c,2005}$	  & $ V_{c,2005}$	& $ V_{c,2005}$	      & $ V_{c,2005}$	    \\ \midrule
tex Population (100,000)  & ${b_m1_1}${st_m1_1} & ${b_m2_1}${st_m2_1} & ${b_m3_1}${st_m3_1} & ${b_m4_1}${st_m4_1} & ${b_m5_1}${st_m5_1} \\
tex 				   	  & (${se_m1_1})   	    & (${se_m2_1})		  & (${se_m3_1})		& (${se_m4_1})		  & (${se_m5_1})		\\
tex 100*Ln(Hrly Wage) 	  & 					& ${b_m2_2}${st_m2_2} & ${b_m3_2}${st_m3_2} & ${b_m4_2}${st_m4_2} & ${b_m5_2}${st_m5_2} \\
tex 				   	  & 					& (${se_m2_2})		  & (${se_m3_2})		& (${se_m4_2})		  & (${se_m5_2})		\\
tex 100*Ln(Hrs per Week)  & 					& 					  & ${b_m3_3}${st_m3_3} & ${b_m4_3}${st_m4_3} & ${b_m5_3}${st_m5_3} \\
tex 				   	  & 					& 					  & (${se_m3_3})		& (${se_m4_3})		  & (${se_m5_3})		\\
tex 100*Unemployment Rate & 			        & 					  & 					& ${b_m4_4}${st_m4_4} & ${b_m5_4}${st_m5_4} \\
tex 				   	  & 					& 					  & 					& (${se_m4_4})		  & (${se_m5_4})		\\
tex 100*LFP Rate		  & 			        & 					  & 					& 					  & ${b_m5_5}${st_m5_5} \\
tex 				   	  & 					& 					  & 					& 					  & (${se_m5_5})		\\
tex N		 & ${N_m1}  & ${N_m2}  & ${N_m3}  & ${N_m4}  & ${N_m5}  \\
tex R$^2$	 & ${r2_m1} & ${r2_m2} & ${r2_m3} & ${r2_m4} & ${r2_m5} \\
tex \bottomrule \bottomrule
tex \end{tabular}
tex \begin{tablenotes}
tex \small
tex \item $ V_{c,2005}$ is the 2005 Venezuelan share of the metro area, which ranges from 0\% to .9\%, and has been normalized to a mean of 0 and SD of 1. Observations weighted by 2014 population. Robust standard errors in parentheses. * p$<$0.10, ** p$<$0.05, *** p$<$0.01.
tex \end{tablenotes}
tex \end{threeparttable}
texdoc close
