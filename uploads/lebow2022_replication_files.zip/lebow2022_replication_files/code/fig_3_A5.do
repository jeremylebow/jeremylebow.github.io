
use "$mydir/data/geih_metro_collapse.dta", clear

set scheme plotplainblind

* ------------------------------------------------------------
* Fig 3 - Wage effect by occupation decile
* ------------------------------------------------------------
local n = 0
foreach d of numlist 1/10 {
	local n = `n' + 1
	qui ivreg2 ln_wage_res_d`d' (ven_5yr_sh = iv_ven05) i.metro i.year [aw=pop_work_d`d'], cluster(metro) partial(i.metro i.year)
	matrix B = e(b)
	matrix V = e(V)
	local y`n' = B[1,1]
	local se`n' = sqrt(V[1,1])
}
preserve
clear
set obs 10
gen x = _n
gen y = .
gen se = .
foreach n of numlist 1/10 {
	replace y  = `y`n''  if x==`n'
	replace se = `se`n'' if x==`n'	
}
gen ci_l = y - se*1.96
gen ci_u = y + se*1.96
eclplot y ci_l ci_u x, yline(0) xtitle("Education-Ranked Occupation Decile") ytitle("") yscale(r(-3 1)) ylabel(-3(.5)1) ///
					   title("Residual Ln Hrly Wage") xscale(r(1 10)) xlabel(1(1)10)
graph export "$mydir/output/fig3.png", replace
restore

* ------------------------------------------------------------
* Fig A5 - Wage effect by sector
* ------------------------------------------------------------

local n = 0
foreach s of numlist 1/4 {
	local n = `n' + 1
	qui ivreg2 ln_wage_res_s`s' (ven_5yr_sh = iv_ven05) i.metro i.year [aw=pop_work_s`s'], cluster(metro) partial(i.metro i.year)
	matrix B = e(b)
	matrix V = e(V)
	local y`n' = B[1,1]
	local se`n' = sqrt(V[1,1])
}
preserve
clear
set obs 4
gen x = _n
gen y = .
gen se = .
foreach n of numlist 1/4 {
	replace y  = `y`n''  if x==`n'
	replace se = `se`n'' if x==`n'	
}
gen ci_l = y - se*1.96
gen ci_u = y + se*1.96
eclplot y ci_l ci_u x, yline(0) xtitle("") ytitle("") yscale(r(-3 2)) ylabel(-3(.5)2) ///
					   title("Residual Ln Hrly Wage") ///
			xlabel(1 "Formal Salaried" 2 "Informal Salaried" 3 "Own Account" 4 "Employer", angle(45))
graph export "$mydir/output/figA5.png", replace
restore

