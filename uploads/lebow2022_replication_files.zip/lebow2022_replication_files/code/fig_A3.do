
use "$mydir/data/geih_metro_collapse.dta", clear

keep if year==2019

keep metro ven_5yr_sh pop14 censo05_ven_born

set scheme plotplainblind

ssc install aaplot

rename ven_5yr_sh Y
rename censo05_ven_born X
aaplot Y X, ///
	   title("Relationship between 2019 and 2005 Migrant Share") ///
	   xtitle("Share Venezuelan-Born in 2005") ///
	   ytitle("Migrant Share in 2019")
graph export "$mydir/output/figA3.png", replace
